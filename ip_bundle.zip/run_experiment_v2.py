# run_experiments_v2.py
import re, json, csv, argparse
from pathlib import Path
from typing import List, Tuple

import numpy as np, tiktoken, yaml
from dotenv import load_dotenv
from openai import OpenAI

# ─────────── init ───────────
load_dotenv()
CFG = yaml.safe_load(Path("experiment.yml").read_text())

ROOT = Path(CFG["notes_root"])
RUNS = Path(CFG["runs_root"])
RUNS.mkdir(exist_ok=True)

ENC4 = tiktoken.encoding_for_model("gpt-4")
client = OpenAI()

SHARED_CTX = int(CFG["shared_ctx_tokens"])
WIDE_MAX = int(CFG["wide_max_tokens"])

# ─────────── Run ID management ───────────
def next_run_id() -> int:
    cfg_file = RUNS / "run_config.json"
    data = {"last_run": 0}
    if cfg_file.exists():
        data.update(json.load(cfg_file.open()))
    data["last_run"] += 1
    cfg_file.write_text(json.dumps(data, indent=2))
    return data["last_run"]

# ─────────── Embedding helpers ───────────
def embed_texts(txts: List[str]) -> List[List[float]]:
    vecs = []
    for i in range(0, len(txts), 100):
        rsp = client.embeddings.create(
            model="text-embedding-3-small",
            input=txts[i:i+100]
        )
        vecs.extend([d.embedding for d in rsp.data])
    return vecs

def cos(a, b):
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9))

# ─────────── Strategies ───────────
def run_wide(note: str, q: str) -> Tuple[str, int]:
    toks = ENC4.encode(note)
    note = ENC4.decode(toks)
    prompt = f"{note}\n\nQuestion: {q}"
    rsp = client.chat.completions.create(
        model=CFG["openai_model_wide"],
        messages=[{"role": "user", "content": prompt}],
        temperature=0, top_p=1
    )
    ans = rsp.choices[0].message.content.strip()
    return ans, len(ENC4.encode(prompt)) + len(ENC4.encode(ans))

def build_rag_ctx(chunks: List[str], q_emb, k=8) -> str:
    sims = [cos(q_emb, e) for e in embed_texts(chunks)]
    top = np.argsort(sims)[-k:][::-1]

    ctx, used = [], 0
    for i in top:
        chunk = chunks[i]
        t = len(ENC4.encode(chunk))
        if used + t > SHARED_CTX:
            break
        ctx.append(chunk); used += t
    return "\n---\n".join(ctx)

def run_rag(note: str, q: str) -> Tuple[str, int]:
    chunks = [c.strip() for c in re.split(r'\n{2,}', note) if len(c.strip()) > 40]
    q_emb  = embed_texts([q])[0]
    ctx    = build_rag_ctx(chunks, q_emb)

    prompt = ("You are a medical assistant. Use ONLY the context.\n\n"
              f"Context:\n{ctx}\n\nQuestion: {q}")
    rsp = client.chat.completions.create(
        model=CFG["openai_model_rag"],
        messages=[{"role": "user", "content": prompt}],
        temperature=0, top_p=1
    )
    ans = rsp.choices[0].message.content.strip()
    return ans, len(ENC4.encode(prompt)) + len(ENC4.encode(ans))

def top_sentences(note: str, q: str) -> str:
    sents = [s.strip() for s in re.split(r'(?<=[.!?])\s+', note) if len(s) > 30]
    embeds = embed_texts(sents + [q])
    q_emb = embeds[-1]
    ranked = sorted(zip([cos(q_emb, e) for e in embeds[:-1]], sents),
                    key=lambda x: x[0], reverse=True)

    ctx, used = [], 0
    for _, sent in ranked:
        t = len(ENC4.encode(sent))
        if used + t > SHARED_CTX:
            break
        ctx.append(sent); used += t
    return "\n".join(ctx)

def run_clear(note: str, q: str) -> Tuple[str, int]:
    ctx = top_sentences(note, q)
    prompt = ("You are a medical assistant. Answer ONLY from the context.\n\n"
              f"Context:\n{ctx}\n\nQuestion: {q}")
    rsp = client.chat.completions.create(
        model=CFG["openai_model_clear"],
        messages=[{"role": "user", "content": prompt}],
        temperature=0, top_p=1, max_tokens=1024
    )
    ans = rsp.choices[0].message.content.strip()
    return ans, len(ENC4.encode(prompt)) + len(ENC4.encode(ans))

# ─────────── Main ───────────
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", nargs="+")
    args = ap.parse_args()

    run_id = next_run_id()
    run_dir = RUNS / f"run{run_id}"
    run_dir.mkdir(parents=True, exist_ok=True)

    csv_file = run_dir / "experiment_summary.csv"
    detail_js = run_dir / "experiment_detailed.json"

    all_cases = sorted([p for p in ROOT.iterdir()
                        if p.is_dir() and p.name.startswith("clinical_note") and "student" not in p.name],
                       key=lambda p: int(p.name.split("clinical_note")[1]))

    if args.cases:
        cases = [p for p in all_cases if p.name.lower() in {c.lower() for c in args.cases}]
    else:
        cases = all_cases

    rows, details = [], []
    for idx, case in enumerate(cases):
        print(f"\n▶ {case.name} ({idx+1}/{len(cases)})")
        note = (case / "clinical_note.txt").read_text()
        q = (case / "question.txt").read_text().strip()
        gold = (case / "gold_standard_answer.txt").read_text().strip()

        w_ans, w_tok = run_wide(note, q); print("   Wide  ✅")
        r_ans, r_tok = run_rag(note, q);  print("   RAG   ✅")
        c_ans, c_tok = run_clear(note, q); print("   CLEAR ✅")

        # Save answers to run folder only
        (run_dir / case.name).mkdir(parents=True, exist_ok=True)
        (run_dir / case.name / "answer_wide.txt").write_text(w_ans)
        (run_dir / case.name / "answer_rag.txt").write_text(r_ans)
        (run_dir / case.name / "answer_clear.txt").write_text(c_ans)

        vecs = embed_texts([w_ans, r_ans, c_ans, gold])
        gold_vec = vecs[-1]
        w_acc, r_acc, c_acc = [cos(v, gold_vec) for v in vecs[:3]]
        best = max([("Wide", w_acc), ("RAG", r_acc), ("CLEAR", c_acc)], key=lambda x: x[1])[0]

        row = {
            "Case": case.name,
            "Note Tokens": len(ENC4.encode(note)),
            "Wide Tokens": w_tok, "RAG Tokens": r_tok, "CLEAR Tokens": c_tok,
            "Wide Accuracy": w_acc, "RAG Accuracy": r_acc, "CLEAR Accuracy": c_acc,
            "Best Strategy": best
        }
        rows.append(row)
        details.append({**row, "Question": q, "Gold": gold,
                        "Wide": w_ans, "RAG": r_ans, "CLEAR": c_ans})

    with csv_file.open("w", newline="") as fh:
        wr = csv.DictWriter(fh, fieldnames=rows[0].keys())
        wr.writeheader(); wr.writerows(rows)

    detail_js.write_text(json.dumps(details, indent=2))
    print(f"\nRun {run_id} complete → {csv_file}")

if __name__ == "__main__":
    main()
