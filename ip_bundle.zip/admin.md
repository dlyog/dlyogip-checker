Now you can use this script from your shell! Here are the commands:
📋 Usage Examples
# List all admins:
bashpython manage_admin.py list
Add admin@dlyog.com:
bashpython manage_admin.py add admin@dlyog.com
# Add any other admin:
bashpython manage_admin.py add newadmin@example.com
# Remove/deactivate an admin:
bashpython manage_admin.py remove badadmin@example.com
# Reactivate an admin:
bashpython manage_admin.py activate admin@dlyog.com
# Permanently delete an admin:
bashpython manage_admin.py delete unwanted@example.com
Get help:
bashpython manage_admin.py help
# 🚀 Quick Setup for Your Case
Run these commands:
bash# 1. See current admins
python manage_admin.py list

# 2. Add admin@dlyog.com
python manage_admin.py add admin@dlyog.com

# 3. Verify it was added
python manage_admin.py list

# 4. TODO