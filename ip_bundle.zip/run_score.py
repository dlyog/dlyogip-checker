# run_score.py
import json
import argparse
import re
from pathlib import Path
from typing import Dict
import matplotlib.pyplot as plt
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from rouge_score import rouge_scorer

# ───────────── Models & Scorers ─────────────
EMBED_MODEL = SentenceTransformer('all-MiniLM-L6-v2')
ROUGE = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)

NOTE_TOKEN_MAP = {
    "clinical_note1": 66416,
    "clinical_note2": 66921,
    "clinical_note3": 27655,
    "clinical_note4": 25510,
    "clinical_note5": 25494,
    "clinical_note6": 25192,
    "clinical_note7": 40191,
    "clinical_note8": 40382,
    "clinical_note9": 40144,
    "clinical_note10": 65920,
    "clinical_note11": 65863,
    "clinical_note12": 65851,
    "clinical_note13": 51875,
    "clinical_note14": 65868,
    "clinical_note15": 10217,
    "clinical_note16": 10068,
}

COLORS = {"Wide": "tab:blue", "RAG": "tab:orange", "CLEAR": "tab:green"}

def embedding_cosine_similarity(text1: str, text2: str) -> float:
    emb1 = EMBED_MODEL.encode([text1])[0]
    emb2 = EMBED_MODEL.encode([text2])[0]
    return float(cosine_similarity([emb1], [emb2])[0][0])

def rouge_l_f1(pred: str, ref: str) -> float:
    return ROUGE.score(ref, pred)['rougeL'].fmeasure

def score_run(run_name: str):
    run_dir = Path("clinical_notes/runs") / run_name
    all_cases = sorted((p for p in run_dir.iterdir() if p.is_dir() and p.name.startswith("clinical_note")),
                       key=lambda p: int(p.name.split("clinical_note")[1]))

    cosine_data: Dict[str, Dict[str, float]] = {}
    rouge_data: Dict[str, Dict[str, float]] = {}
    winner_cosine: Dict[str, Dict] = {}
    winner_rouge: Dict[str, Dict] = {}

    for case in all_cases:
        case_name = case.name
        base_note_dir = Path("clinical_notes") / case_name

        try:
            gold = (base_note_dir / "gold_standard_answer.txt").read_text().strip()
            w_ans = (case / "answer_wide.txt").read_text().strip()
            r_ans = (case / "answer_rag.txt").read_text().strip()
            c_ans = (case / "answer_clear.txt").read_text().strip()
            note_tokens = NOTE_TOKEN_MAP[case_name]
        except FileNotFoundError as e:
            print(f"⚠️ Skipping {case_name}, missing file: {e.filename}")
            continue
        except KeyError:
            print(f"⚠️ Skipping {case_name}, no token count found")
            continue

        cosine_scores = {
            "Wide": embedding_cosine_similarity(w_ans, gold),
            "RAG": embedding_cosine_similarity(r_ans, gold),
            "CLEAR": embedding_cosine_similarity(c_ans, gold),
        }
        rouge_scores = {
            "Wide": rouge_l_f1(w_ans, gold),
            "RAG": rouge_l_f1(r_ans, gold),
            "CLEAR": rouge_l_f1(c_ans, gold),
        }

        cosine_data[case_name] = cosine_scores
        rouge_data[case_name] = rouge_scores

        # Track winner per note for each metric
        best_cosine_strategy = max(cosine_scores, key=cosine_scores.get)
        best_rouge_strategy = max(rouge_scores, key=rouge_scores.get)
        winner_cosine[case_name] = {
            "strategy": best_cosine_strategy,
            "score": cosine_scores[best_cosine_strategy],
            "tokens": note_tokens,
        }
        winner_rouge[case_name] = {
            "strategy": best_rouge_strategy,
            "score": rouge_scores[best_rouge_strategy],
            "tokens": note_tokens,
        }

    # Save as JSON (for provenance)
    (run_dir / "run_cosine.json").write_text(json.dumps(cosine_data, indent=2))
    (run_dir / "run_rouge.json").write_text(json.dumps(rouge_data, indent=2))
    (run_dir / "run_winner_cosine.json").write_text(json.dumps(winner_cosine, indent=2))
    (run_dir / "run_winner_rouge.json").write_text(json.dumps(winner_rouge, indent=2))

    print(f"✅ Scoring complete. Cosine, ROUGE, and winner files written.")

    # ───────────── Plotting Functions ─────────────
    def plot_metric(metric_data, metric_name, out_name):
        strategies = ["Wide", "RAG", "CLEAR"]
        sorted_notes = sorted(metric_data.items(), key=lambda x: NOTE_TOKEN_MAP[x[0]])
        x_vals = [NOTE_TOKEN_MAP[n[0]] for n in sorted_notes]
        plt.figure(figsize=(14, 6))
        for strategy in strategies:
            y_vals = [n[1][strategy] for n in sorted_notes]
            plt.plot(x_vals, y_vals, label=strategy, marker='o', linewidth=2, color=COLORS[strategy])
        plt.xlabel("Token Count")
        plt.ylabel(metric_name)
        plt.title(f"Model Strategy {metric_name} Trend by Token Size")
        plt.xticks([10000,20000,30000,40000,50000,60000,70000], labels=["10k","20k","30k","40k","50k","60k","70k"])
        plt.xlim(9500, 70500)
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig(run_dir / out_name)
        plt.close()
        print(f"📊 {metric_name} trend saved to {run_dir / out_name}")

    def plot_winner(winner_data, metric_name, out_name):
        plt.figure(figsize=(14, 6))
        for strat in COLORS:
            x = [v["tokens"] for v in winner_data.values() if v["strategy"] == strat]
            y = [v["score"] for v in winner_data.values() if v["strategy"] == strat]
            plt.scatter(x, y, label=strat, color=COLORS[strat], s=120, marker='o', edgecolors='black')
        plt.xlabel("Token Count")
        plt.ylabel(metric_name)
        plt.title(f"Best Strategy ({metric_name}) By Note Size")
        plt.xticks([10000,20000,30000,40000,50000,60000,70000], labels=["10k","20k","30k","40k","50k","60k","70k"])
        plt.xlim(9500, 70500)
        plt.grid(True, alpha=0.3)
        plt.legend(title="Winner Strategy")
        plt.tight_layout()
        plt.savefig(run_dir / out_name)
        plt.close()
        print(f"🏆 Winner {metric_name} plot saved to {run_dir / out_name}")

    # ───────────── Make All Plots ─────────────
    plot_metric(cosine_data, "Cosine Similarity", "score_trend_by_token_size_cosine.png")
    plot_metric(rouge_data, "ROUGE-L F1", "score_trend_by_token_size_rouge.png")
    plot_winner(winner_cosine, "Cosine Similarity", "winner_trend_by_token_size_cosine.png")
    plot_winner(winner_rouge, "ROUGE-L F1", "winner_trend_by_token_size_rouge.png")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("run_name", type=str, help="Run name like 'run1' or 'run2'")
    args = parser.parse_args()
    score_run(args.run_name)
