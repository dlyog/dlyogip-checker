#!/usr/bin/env python3
"""
FlameGuardAI MCP Server - Production HTTP/SSE Version
Supports both stdio (local) and HTTP/SSE (remote) transports
"""

import os
import logging
import asyncio
import argparse
from typing import Any, Dict, Optional
import httpx
from datetime import datetime
from dotenv import load_dotenv
import json
import uuid

# FastAPI imports for HTTP/SSE server
from fastapi import FastAPI, Request, HTTPException, Header
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# Official MCP SDK imports
from mcp.server.fastmcp import FastMCP
from mcp.server.sse import SseServerTransport
from loguru import logger
from starlette.applications import Starlette
from starlette.routing import Mount, Route

# Load MCP environment variables
load_dotenv('.env.mcp')

# Set up logging
logging.basicConfig(level=logging.INFO)

class FlameGuardMCPServer:
    def __init__(self):
        # Create MCP server using official SDK
        self.mcp = FastMCP("FlameGuardAI Fire Risk Research")
        self.api_base_url = os.getenv("FLAMEGUARD_API_URL", "http://localhost:5000")
        self.api_base_ext_url = os.getenv("FLAMEGUARD_API_EXT_URL", "https://flameguardai.dlyog.com")
        self.api_token = os.getenv("FLAMEGUARD_API_TOKEN", "")
        
        # Store user sessions for this MCP server instance
        self.authenticated_users = {}  # email -> session_token mapping
        self.active_sse_sessions = {}  # session_id -> connection info
        
        logger.info(f"Starting FlameGuardAI MCP Server")
        logger.info(f"API Base URL: {self.api_base_url}")
        logger.info(f"Token configured: {'✅' if self.api_token else '❌'}")
        
        # Register tools
        self.setup_tools()

    def setup_tools(self):
        @self.mcp.tool()
        async def request_auth_code(email: str) -> str:
            """
            Request authentication code for FlameGuardAI MCP access.
            
            Uses the FlameGuardAI web app's authentication system via API calls.
            Only works for existing, active FlameGuardAI users.
            
            Args:
                email: User's registered email address
            
            Returns:
                Status message with instructions
            """
            logger.info(f"Authentication code requested for: {email}")
            
            try:
                # Call MCP-specific request code endpoint
                async with httpx.AsyncClient() as client:
                    response = await client.post(
                        f"{self.api_base_url}/api/mcp/request-code",
                        json={"email": email},
                        headers={"User-Agent": "FlameGuardAI-MCP-Server/1.0"},
                        timeout=10.0
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        if result.get("success"):
                            return f"""✅ Authentication code sent successfully!

📧 Email: {email}
📨 A 6-digit verification code has been sent to your email address.

📝 Next step: Use the 'authenticate_user' tool with your email and the 6-digit code from your email to complete authentication.

⏰ Code expires in 10 minutes."""
                        else:
                            return f"❌ Authentication failed: {result.get('error', 'Unknown error')}"
                    else:
                        error_data = response.json() if response.headers.get('content-type', '').startswith('application/json') else {}
                        error_msg = error_data.get('error', f'Request failed with status {response.status_code}')
                        return f"❌ Authentication failed: {error_msg}"
                    
            except httpx.RequestError as e:
                logger.error(f"Error calling Flask app: {e}")
                return f"❌ Error: Cannot connect to FlameGuardAI service. Please ensure the web app is running."
            except Exception as e:
                logger.error(f"Error requesting auth code: {e}")
                return f"❌ Error: Failed to send authentication code. Please try again."

        @self.mcp.tool()
        async def authenticate_user(email: str, code: str) -> str:
            """
            Authenticate user with verification code for FlameGuardAI MCP access.
            
            Complete the authentication process by providing the 6-digit code
            sent to your email address.
            
            Args:
                email: User's registered email address
                code: 6-digit verification code from email
            
            Returns:
                Authentication status and session information
            """
            logger.info(f"Authentication attempt for: {email}")
            
            try:
                # Call MCP-specific verify code endpoint
                async with httpx.AsyncClient() as client:
                    response = await client.post(
                        f"{self.api_base_url}/api/mcp/verify-code",
                        json={
                            "email": email,
                            "code": code
                        },
                        headers={"User-Agent": "FlameGuardAI-MCP-Server/1.0"},
                        timeout=10.0
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        if result.get("success"):
                            session_token = result.get("session_token")
                            
                            # Store session token for this user in MCP server
                            self.authenticated_users[email] = {
                                'session_token': session_token,
                                'user_id': result.get("user_id"),
                                'authenticated_at': datetime.now()
                            }
                            
                            return f"""✅ Authentication successful!

👤 User: {email}
🔑 Session established
⏰ Session active for this conversation

🔥 You can now use the 'fire_risk_deep_research' tool to analyze your property for fire risks!

Example: "Analyze my property for fire risks. I have a wooden roof and dry vegetation near the house. ZIP code is 90210, California."
"""
                        else:
                            return f"❌ Authentication failed: {result.get('error', 'Unknown error')}"
                    else:
                        error_data = response.json() if response.headers.get('content-type', '').startswith('application/json') else {}
                        error_msg = error_data.get('error', f'Verification failed with status {response.status_code}')
                        return f"❌ Authentication failed: {error_msg}"
                    
            except httpx.RequestError as e:
                logger.error(f"Error calling Flask app: {e}")
                return f"❌ Error: Cannot connect to FlameGuardAI service."
            except Exception as e:
                logger.error(f"Error authenticating user: {e}")
                return f"❌ Error: Authentication failed. Please try again."

        @self.mcp.tool()
        async def fire_risk_deep_research(
            email: str,
            image_analysis: str, 
            zip_code: str,
            state: str = "CA",
            additional_context: str = ""
        ) -> str:
            """
            Trigger comprehensive AI fire risk research analysis using Perplexity API.
            
            ⚠️ AUTHENTICATION REQUIRED: You must authenticate first using 'request_auth_code' 
            and 'authenticate_user' tools before using this tool.
            
            Analyzes property descriptions and provides detailed fire prevention recommendations,
            DIY solutions, professional resources, and material supplier information.
            
            Args:
                email: Your authenticated email address
                image_analysis: Detailed description of the property showing fire risk factors
                zip_code: Property ZIP code for local research context (5 digits)
                state: Property state code (e.g., CA, TX, FL)
                additional_context: Additional context about the property or specific concerns (optional)
            
            Returns:
                Status message with assessment ID and instructions
            """
            logger.info(f"Fire risk research requested by: {email}")
            
            # Check if user is authenticated in MCP server
            if email not in self.authenticated_users:
                return """❌ Authentication required!

Please authenticate first by:
1. Use 'request_auth_code' tool with your email
2. Check your email for the 6-digit code
3. Use 'authenticate_user' tool with your email and code
4. Then retry this fire risk research tool"""
            
            # Validate required fields
            if not image_analysis:
                return "❌ Error: Property description/image analysis is required."
                
            if not zip_code or len(zip_code) != 5 or not zip_code.isdigit():
                return "❌ Error: Valid 5-digit ZIP code is required."
            
            # Get user session info
            user_session = self.authenticated_users[email]
            session_token = user_session['session_token']
            
            try:
                # Validate session is still active using MCP-specific endpoint
                async with httpx.AsyncClient() as client:
                    validation_response = await client.post(
                        f"{self.api_base_url}/api/mcp/validate-session",
                        json={"session_token": session_token},
                        headers={"User-Agent": "FlameGuardAI-MCP-Server/1.0"},
                        timeout=5.0
                    )
                    
                    if validation_response.status_code != 200:
                        # Session expired, remove from our cache
                        del self.authenticated_users[email]
                        return """❌ Authentication session expired!

Your authentication session has expired. Please authenticate again:
1. Use 'request_auth_code' tool with your email
2. Check your email for the 6-digit code  
3. Use 'authenticate_user' tool with your email and code
4. Then retry this fire risk research tool"""
                    
                    user_info = validation_response.json()
                    if not user_info.get("valid"):
                        del self.authenticated_users[email]
                        return """❌ Authentication session expired!

Your authentication session has expired. Please authenticate again:
1. Use 'request_auth_code' tool with your email
2. Check your email for the 6-digit code  
3. Use 'authenticate_user' tool with your email and code
4. Then retry this fire risk research tool"""
                
                # Now trigger the fire risk analysis using MCP-specific endpoints
                return await self._trigger_fire_risk_analysis(
                    session_token=session_token,
                    user_id=user_info["user_id"],
                    email=email,
                    image_analysis=image_analysis,
                    zip_code=zip_code,
                    state=state,
                    additional_context=additional_context
                )
                
            except Exception as e:
                logger.error(f"Error in fire risk research: {e}")
                return "❌ Error: Fire risk analysis failed. Please try again."

        @self.mcp.tool()
        async def logout_user(email: str) -> str:
            """
            Logout user and invalidate authentication session.
            
            Args:
                email: User's email address to logout
            
            Returns:
                Logout status message
            """
            logger.info(f"Logout requested for: {email}")
            
            if email in self.authenticated_users:
                try:
                    # Remove from our cache
                    del self.authenticated_users[email]
                    return f"✅ Successfully logged out {email}"
                    
                except Exception as e:
                    logger.error(f"Error during logout: {e}")
                    return f"⚠️ Logged out {email} (with some errors)"
            else:
                return f"ℹ️ No active session found for {email}"

    async def _trigger_fire_risk_analysis(
        self, 
        session_token: str, 
        user_id: str, 
        email: str, 
        image_analysis: str,
        zip_code: str, 
        state: str, 
        additional_context: str
    ) -> str:
        """
        Trigger fire risk analysis using MCP-specific API endpoints
        """
        try:
            async with httpx.AsyncClient() as client:
                # Call MCP-specific analyze endpoint
                analyze_data = {
                    'session_token': session_token,
                    'image_analysis': image_analysis,
                    'zip_code': zip_code,
                    'state': state,
                    'image_path': f"mcp_generated_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                }
                
                response = await client.post(
                    f"{self.api_base_url}/api/mcp/analyze",
                    data=analyze_data,
                    headers={"User-Agent": "FlameGuardAI-MCP-Server/1.0"},
                    timeout=30.0
                )
                
                # --- handle expected non-200 cases first ---
                if response.status_code == 401:                     # no / expired session
                    detail = response.json().get("error", "Unauthorized")
                    return f"🔑 Session invalid: {detail}"

                if response.status_code == 403:                     # out of credits or blocked
                    err = response.json()
                    if err.get("error_type") == "insufficient_credits":
                        return ("🚫 You have no remaining assessment credits.\n"
                                "Please purchase or request additional credits before running "
                                "another fire-risk analysis.")
                    return f"🚫 Access denied: {err.get('error', 'Forbidden')}"

                # --- any other HTTP error ---
                if not response.status_code == 200:
                    detail = response.text or response.reason_phrase
                    return f"❌ Failed to create assessment: HTTP {response.status_code} – {detail}"

                
                analyze_result = response.json()
                assessment_id = analyze_result.get("assessment_id")
                
                if not assessment_id:
                    return "❌ Failed to create assessment: No assessment ID returned"
                
                # Now trigger deep research using MCP-specific endpoint
                report_data = {
                    "session_token": session_token,
                    "assessment_id": assessment_id,
                    "detail": image_analysis,
                    "context": additional_context,
                    "zip": zip_code,
                    "state": state,
                    "deep_research": True
                }
                
                response = await client.post(
                    f"{self.api_base_url}/api/mcp/report",
                    json=report_data,
                    headers={"User-Agent": "FlameGuardAI-MCP-Server/1.0"},
                    timeout=120.0  # Longer timeout for deep research
                )
                
                if response.status_code == 401:
                    return "🔑 Session expired while queuing deep research. Please log in again."

                if response.status_code == 403:
                    err = response.json()
                    return f"🚫 Deep research forbidden: {err.get('error', 'Forbidden')}"

                if not response.status_code == 200:
                    detail = response.text or response.reason_phrase
                    return f"❌ Deep research failed: HTTP {response.status_code} – {detail}"

                
                #research_result = response.json()
                
                logger.info(f"Deep research completed successfully for assessment: {assessment_id}")
                
                # Success response
                return f"""✅ Deep fire risk research initiated successfully!

👤 Authenticated User: {email}
📍 Location: {zip_code}, {state}
🆔 Assessment ID: {assessment_id}

🔬 Comprehensive AI analysis is now running using Perplexity API. This includes:
• Educational DIY fire prevention solutions
• Professional resource research
• Material supplier information
• Local permit and safety requirements

📨 You will receive a detailed report via email once the research is complete (typically 5-8 minutes).

🌐 You can also view results at: {self.api_base_ext_url}/assessment/{assessment_id}

✨ FlameGuardAI research workflow has been triggered successfully!"""
                
        except Exception as e:
            logger.error(f"Error triggering fire risk analysis: {e}")
            return f"❌ Error: Fire risk analysis failed - {str(e)}"

    def create_sse_server(self) -> Starlette:
        """Create Starlette app for SSE transport"""
        transport = SseServerTransport("/messages/")
        
        async def handle_sse(request):
            """Handle SSE connection"""
            session_id = str(uuid.uuid4())
            logger.info(f"New SSE connection: {session_id}")
            
            # Store session info
            self.active_sse_sessions[session_id] = {
                'created_at': datetime.now(),
                'remote_addr': request.client.host if request.client else 'unknown'
            }
            
            try:
                async with transport.connect_sse(
                    request.scope, request.receive, request._send
                ) as streams:
                    await self.mcp._mcp_server.run(
                        streams[0], streams[1], 
                        self.mcp._mcp_server.create_initialization_options()
                    )
            except Exception as e:
                logger.error(f"SSE connection error for {session_id}: {e}")
            finally:
                # Clean up session
                if session_id in self.active_sse_sessions:
                    del self.active_sse_sessions[session_id]
                logger.info(f"SSE connection closed: {session_id}")
        
        # Create routes for SSE transport
        routes = [
            Route("/sse/", endpoint=handle_sse),
            Mount("/messages/", app=transport.handle_post_message),
        ]
        
        return Starlette(routes=routes)

    def create_fastapi_app(self) -> FastAPI:
        """Create FastAPI app that includes both regular endpoints and SSE"""
        app = FastAPI(
            title="FlameGuardAI MCP Server",
            description="Production MCP Server for Fire Risk Assessment",
            version="1.0.0"
        )
        
        # Add CORS middleware
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],  # Configure appropriately for production
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        # Health check endpoint
        @app.get("/health")
        async def health_check():
            return {
                "status": "healthy",
                "service": "FlameGuardAI MCP Server",
                "version": "1.0.0",
                "active_sessions": len(self.active_sse_sessions),
                "authenticated_users": len(self.authenticated_users)
            }
        
        # OAuth discovery endpoints (for future authentication)
        @app.get("/.well-known/oauth-authorization-server")
        async def oauth_authorization_server():
            base_url = os.getenv("MCP_BASE_URL", "http://localhost:8000")
            return {
                "issuer": base_url,
                "authorization_endpoint": f"{base_url}/oauth/authorize",
                "token_endpoint": f"{base_url}/oauth/token",
                "scopes_supported": ["mcp:access"],
                "response_types_supported": ["code"],
                "grant_types_supported": ["authorization_code"]
            }
        
        # Mount the SSE server
        sse_app = self.create_sse_server()
        app.mount("/", sse_app)
        
        return app

    def run_stdio(self):
        """Run the MCP server using stdio transport (for local development)"""
        self.mcp.run(transport="stdio")

    def run_http_server(self, host: str = "0.0.0.0", port: int = 8000):
        """Run the MCP server as HTTP/SSE server for remote access"""
        app = self.create_fastapi_app()
        
        logger.info(f"Starting HTTP/SSE server on {host}:{port}")
        logger.info(f"SSE endpoint will be available at: http://{host}:{port}/sse/")
        logger.info(f"Health check available at: http://{host}:{port}/health")
        
        uvicorn.run(
            app, 
            host=host, 
            port=port,
            log_level="info",
            access_log=True
        )


def main():
    """Main entry point with argument parsing"""
    parser = argparse.ArgumentParser(description="FlameGuardAI MCP Server")
    parser.add_argument("--mode", choices=["stdio", "http"], default="stdio",
                      help="Server mode: stdio for local, http for remote")
    parser.add_argument("--host", default="0.0.0.0", help="HTTP server host")
    parser.add_argument("--port", type=int, default=8000, help="HTTP server port")
    
    args = parser.parse_args()
    
    try:
        server = FlameGuardMCPServer()
        
        if args.mode == "stdio":
            logger.info("Running in stdio mode (local)")
            server.run_stdio()
        else:
            logger.info(f"Running in HTTP/SSE mode (remote) on {args.host}:{args.port}")
            server.run_http_server(args.host, args.port)
            
    except KeyboardInterrupt:
        logger.info("Server shutting down...")
    except Exception as e:
        logger.error(f"Server error: {e}")
        exit(1)


if __name__ == "__main__":
    main()