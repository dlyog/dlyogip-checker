# generate_batch_notes_v3.py
"""
Generate 9 synthetic clinical notes:
  • 3 SMALL  ~25k tokens
  • 3 MEDIUM ~40k tokens
  • 3 LARGE  ~60k tokens

Each note lives in clinical_notes/clinical_note{N}/
Files: clinical_note.txt, question.txt, gold_standard_answer.txt, state.json
Safe to interrupt & rerun.
"""

from __future__ import annotations
import random, json
from pathlib import Path
from typing import Dict
from dotenv import load_dotenv
from openai import OpenAI
import tiktoken

load_dotenv()
client = OpenAI()
ENC = tiktoken.encoding_for_model("gpt-3.5-turbo")

BASE_DIR  = Path("clinical_notes")
START_IDX = 4          # first new note
SEED = 42; random.seed(SEED)

TARGETS: Dict[str, int] = {
    "SMALL":  10_000,
    "MEDIUM": 40_000,
    "LARGE":  60_000,
}

PATIENT_PROFILES = [
    ("male with type-2 diabetes and hypertension", "heart failure"),
    ("female with strong family history of breast cancer", "breast cancer"),
    ("male former smoker with COPD", "heart failure"),
]

TEMPLATE = """
### Year: {year}
### Patient profile
{profile}

### Subjective  (≈200-250 words)
{{subjective}}

### Objective / Vitals  (≈200-250 words)
{{objective}}

### Labs & Imaging  (≈200-250 words)
{labs}

### Assessment  (≈200-250 words)
{{assessment}}

### Plan  (≈200-250 words)
{{plan}}
""".strip()

SYSTEM = ("You are a clinical documentation LLM. "
          "Fill every {{ }} with medically plausible text in the requested length.")

def bucket(n:int)->str:
    if n < 30_000: return "SMALL"
    if n <=50_000: return "MEDIUM"
    return "LARGE"

def planted_and_qa(topic:str):
    if topic=="heart failure":
        planted={1966:"dyspnea + BP 145/95",1971:"LVH ECG",1979:"EF 45%",1984:"CHF admission"}
        q="Could the patient's heart failure in 1984 have been prevented based on earlier signs?"
        a=("Yes – dyspnea & high BP in 1966, LV hypertrophy in 1971, reduced EF in 1979. "
           "Timely therapy might have averted heart failure.")
    else:
        planted={2005:"breast lump",2008:"suspicious mammogram",2013:"DCIS MRI",2019:"Stage II cancer"}
        q="Could the patient's breast cancer diagnosis in 2019 have been prevented with earlier intervention?"
        a=("Yes – lump (2005), suspicious mammogram (2008), DCIS (2013) signalled risk. "
           "Early action could have prevented progression.")
    return planted,q,a

def gen_year_text(year:int, profile:str, fact:str|None):
    user=TEMPLATE.format(year=year, profile=profile,
                         labs=f"{{labs}}{f' Include: {fact}' if fact else ''}")
    rsp=client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role":"system","content":SYSTEM},
                  {"role":"user","content":user}],
        temperature=0.4,
        max_tokens=2400
    )
    return rsp.choices[0].message.content.strip()

def ensure(d:Path): d.mkdir(parents=True, exist_ok=True)

# ─────────────────────────────────────
note_idx=START_IDX
for target_bucket,target_tokens in TARGETS.items():          # SMALL → MEDIUM → LARGE
    for _ in range(3):
        d=BASE_DIR/f"clinical_note{note_idx}"; ensure(d)
        note_f = d/"clinical_note.txt"
        q_f    = d/"question.txt"
        gold_f = d/"gold_standard_answer.txt"
        state  = d/"state.json"

        profile,topic=random.choice(PATIENT_PROFILES)
        planted,q,gold=planted_and_qa(topic)

        if state.exists():
            st=json.load(state.open())
            year=int(st["year"])+1
            n_tok=st["tokens"]
        else:
            note_f.write_text(f"Patient profile: {profile}\n\n",encoding="utf-8")
            year=1965
            n_tok=len(ENC.encode(profile))

        while n_tok < target_tokens:
            txt=gen_year_text(year,profile,planted.get(year))
            header=f"--- {year} ---\n"
            with note_f.open("a",encoding="utf-8") as f:
                f.write(header+txt+"\n\n")
            n_tok += len(ENC.encode(header))+len(ENC.encode(txt))

            # checkpoint
            json.dump({"year":year,"tokens":n_tok}, state.open("w"))
            print(f"{d.name} · {year} · {n_tok}/{target_tokens} tokens")
            year+=1

        q_f.write_text(q,encoding="utf-8")
        gold_f.write_text(gold,encoding="utf-8")
        print(f"✅ Finished {d.name}  ({n_tok} tokens → {bucket(n_tok)})\n")
        note_idx+=1
