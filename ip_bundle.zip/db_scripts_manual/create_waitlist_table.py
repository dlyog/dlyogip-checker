"""
FlameGuardAI™ – wait-list for “at capacity” sign-ups
Run:  python create_waitlist_table.py
"""
import os, sys, psycopg2, json
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from datetime import datetime
from dotenv import load_dotenv

# ───── ENV / DB CONFIG ─────
load_dotenv("target.env")        # optional .env file
# Database configuration
DB_CONFIG = {
    'host': os.getenv('PG_HOST', 'dlyog02'),
    'port': os.getenv('PG_PORT', '5432'),
    'user': os.getenv('PG_USER', 'dlyog'),
    'password': os.getenv('PG_PASSWORD', ''),
    'database': os.getenv('PG_DB', 'flameguard_db_v1')
}

def run():
    print("\nFlameGuardAI™ – create signup_waitlist")
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cur  = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS signup_waitlist (
                id            SERIAL PRIMARY KEY,
                email         VARCHAR(255) UNIQUE NOT NULL,
                requested_at  TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
        """)
        cur.close(); conn.close()
        print("✅  Table ready")
        return True
    except Exception as e:
        print(f"❌  Migration failed: {e}")
        return False

if __name__ == "__main__":
    sys.exit(0 if run() else 1)
