#!/usr/bin/env python
"""
generate_notes_cli.py
---------------------

CLI utility to create **or extend** synthetic clinical notes.

Usage examples
--------------
# create 2 fresh LARGE notes (or extend the two oldest unfinished ones)
python generate_notes_cli.py --bucket LARGE --n 2

# add one MEDIUM note
python generate_notes_cli.py --bucket MEDIUM --n 1
"""
from __future__ import annotations

import argparse, json, os, random, sys, time
from pathlib import Path
from typing import Dict, Tuple, List

import tiktoken
from dotenv import load_dotenv
from openai import OpenAI

# ───────────────────────── config ──────────────────────────
load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
ENC = tiktoken.encoding_for_model("gpt-3.5-turbo")

BUCKET_TARGETS = {
    "SMALL": 10_000,
    "MEDIUM": 42_000,
    "LARGE": 65_000,
}
YEARS_PER_NOTE = 70
BASE_YEAR = 1965

PATIENT_PROFILES: List[Tuple[str, str]] = [
    ("male with type-2 diabetes and hypertension", "heart failure"),
    ("female with strong family history of breast cancer", "breast cancer"),
    ("male former smoker with COPD", "heart failure"),
]

TEMPLATE = """
### Year: {year}
### Patient profile
{profile}

### Subjective (≤60 words)
{{subjective}}

### Objective / Vitals (≤80 words)
{{objective}}

### Labs & Imaging (≤80 words)
{labs}

### Assessment (≤80 words)
{{assessment}}

### Plan (≤80 words)
{{plan}}
""".strip()

SYSTEM_MSG = "You are a clinical documentation LLM. Fill the {{ }} sections."
MODELS = ["gpt-3.5-turbo"] * 3

ROOT = Path("clinical_notes")


# ───────────────────── helper functions ─────────────────────
def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def make_prompt(year: int, profile: str, custom_fact: str | None) -> list[dict]:
    user = TEMPLATE.format(
        year=year,
        profile=profile,
        labs=f"{{labs}}{f' Include: {custom_fact}' if custom_fact else ''}",
    )
    return [
        {"role": "system", "content": SYSTEM_MSG},
        {"role": "user", "content": user},
    ]


def generate_year_text(year: int, profile: str, custom_fact: str | None) -> str:
    messages = make_prompt(year, profile, custom_fact)
    rsp = client.chat.completions.create(
        model=random.choice(MODELS),
        messages=messages,
        temperature=0.4,
        max_tokens=700,
    )
    return rsp.choices[0].message.content.strip()


def token_len(txt: str) -> int:
    return len(ENC.encode(txt))


# ────────────────── main create/extend logic ─────────────────
def initialise_state(
    case_dir: Path, profile: str, bucket: str
) -> Dict[str, int | str]:
    """Create brand-new note directory and seed state.json & clinical_note.txt."""
    ensure_dir(case_dir)
    (case_dir / "clinical_note.txt").write_text(f"Patient profile: {profile}\n\n")
    return {
        "profile": profile,
        "bucket": bucket,
        "year_idx": 0,
        "tokens": token_len(profile),
    }


def guess_profile_from_note(note_path: Path) -> str:
    """Fallback if old state.json lacks 'profile'."""
    try:
        first = note_path.read_text().splitlines()[0]
        if ":" in first:
            return first.split(":", 1)[1].strip()
        return first.strip() or "male with unspecified history"
    except Exception:
        return "male with unspecified history"


def planted_facts(topic: str) -> Tuple[Dict[int, str], str, str, int]:
    """Return (facts, question, gold_answer, final_year)."""
    if topic == "heart failure":
        facts = {
            1966: "mild exertional dyspnea + elevated BP 145/95.",
            1971: "ECG LV hypertrophy, no follow-up.",
            1979: "Ejection fraction 45 %, early systolic dysfunction.",
            1984: "Admitted congestive heart failure, severe LV dysfunction.",
        }
        q = "Could the patient's heart failure in 1984 have been prevented based on earlier signs?"
        gold = (
            "Yes, there were multiple early indicators: dyspnea & high BP in 1966, "
            "LV hypertrophy in 1971, reduced EF in 1979. Early action might have prevented HF."
        )
        return facts, q, gold, 1984
    else:  # breast cancer
        facts = {
            2005: "small palpable breast lump; follow-up imaging advised.",
            2008: "Mammogram suspicious; biopsy recommended but not done.",
            2013: "MRI showed DCIS; treatment deferred.",
            2019: "Diagnosed Stage II breast cancer.",
        }
        q = "Could the patient's breast cancer diagnosis in 2019 have been prevented with earlier intervention?"
        gold = (
            "Yes: lump in 2005, suspicious mammogram 2008, DCIS in 2013 were clear warning signs. "
            "Timely treatment could have prevented cancer progression."
        )
        return facts, q, gold, 2019


def create_or_extend_note(index: int, bucket: str, bucket_target: int) -> None:
    case_dir = ROOT / f"clinical_note{index}"
    state_path = case_dir / "state.json"

    # -------- load or create state --------
    if state_path.exists():
        state = json.loads(state_path.read_text())
        profile: str = state.get("profile") or guess_profile_from_note(
            case_dir / "clinical_note.txt"
        )
        bucket = state.get("bucket", bucket)
        year_idx = state.get("year_idx", 0)
        tokens = state.get("tokens", 0)
        if tokens == 0:  # recompute once for very old notes
            tokens = token_len((case_dir / "clinical_note.txt").read_text())
    else:
        # fresh note
        profile, topic = random.choice(PATIENT_PROFILES)
        state = initialise_state(case_dir, profile, bucket)
        year_idx, tokens = 0, state["tokens"]
        state_path.write_text(json.dumps(state))
        topic = profile.split()[-1] if "breast" in profile else "heart failure"

    # derive topic again if not stored
    topic = "breast cancer" if "breast" in profile else "heart failure"

    facts, question, gold_answer, final_year = planted_facts(topic)
    note_file = case_dir / "clinical_note.txt"
    q_file = case_dir / "question.txt"
    gold_file = case_dir / "gold_standard_answer.txt"

    years = list(range(BASE_YEAR, BASE_YEAR + YEARS_PER_NOTE))

    for year in years[year_idx:]:
        if tokens >= bucket_target:
            break
        txt = generate_year_text(year, profile, facts.get(year))
        header = f"--- {year} ---\n"
        with note_file.open("a", encoding="utf-8") as f:
            f.write(header + txt + "\n\n")
        tokens += token_len(header) + token_len(txt)

        # update & persist state
        state.update({"year_idx": years.index(year) + 1, "tokens": tokens})
        state_path.write_text(json.dumps(state))

        print(f"{case_dir.name} · {year} · {tokens}/{bucket_target} tokens")

    # finished bucket?
    if tokens >= bucket_target:
        q_file.write_text(question)
        gold_file.write_text(gold_answer)
        print(
            f"✅ Finished {case_dir.name}  ({tokens} tokens → {bucket})",
            flush=True,
        )


# ──────────────────────── CLI entrypoint ────────────────────────
def next_index() -> int:
    """Return the next unused integer index for a note."""
    existing = [
        int(p.name.replace("clinical_note", ""))
        for p in ROOT.glob("clinical_note*")
        if p.name.replace("clinical_note", "").isdigit()
    ]
    return max(existing, default=0) + 1


def unfinished_notes(bucket: str, bucket_target: int) -> List[Path]:
    """Return dirs that belong to *bucket* and have < target tokens."""
    res: List[Path] = []
    for p in ROOT.glob("clinical_note*"):
        st_path = p / "state.json"
        if not st_path.exists():
            continue
        st = json.loads(st_path.read_text())
        if st.get("bucket", bucket) != bucket:
            continue
        tokens = st.get("tokens", 0)
        if tokens < bucket_target:
            res.append(p)
    return sorted(res, key=lambda x: x.stat().st_mtime)  # oldest first


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Generate or extend clinical notes")
    ap.add_argument("--bucket", choices=BUCKET_TARGETS, required=True)
    ap.add_argument("--n", type=int, default=1, help="how many notes to process")
    return ap.parse_args()


def main() -> None:
    args = parse_args()
    bucket_target = BUCKET_TARGETS[args.bucket]

    ROOT.mkdir(exist_ok=True)

    # 1️⃣ finish any existing unfinished notes first
    todo_dirs = unfinished_notes(args.bucket, bucket_target)
    todo_count = args.n

    for d in todo_dirs[: todo_count]:
        idx = int(d.name.replace("clinical_note", ""))
        create_or_extend_note(idx, args.bucket, bucket_target)
        todo_count -= 1

    # 2️⃣ need more? create fresh ones
    idx = next_index()
    for _ in range(todo_count):
        create_or_extend_note(idx, args.bucket, bucket_target)
        idx += 1


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
