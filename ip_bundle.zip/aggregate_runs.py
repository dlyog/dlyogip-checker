#!/usr/bin/env python
# aggregate_runs.py
"""
Collate all run-level CSVs under clinical_notes/runs/ into a single
summary; bucket each note by length; decide per-note “winner”
using the cosine-similarity margin in experiment.yml.

Outputs
───────
• Pretty-printed bucket table to stdout
• clinical_notes/runs/aggregate_summary.json
"""

import csv, json, yaml, math
from pathlib import Path
from collections import defaultdict, Counter
from statistics import mean

# ─── config & constants ────────────────────────────────────────────────
CFG         = yaml.safe_load(Path("experiment.yml").read_text())
RUNS_DIR    = Path(CFG["runs_root"])
MARGIN      = CFG["win_margin"]

# bucket cut-offs (tokens, same as earlier scripts)
# bucket cut-offs (tokens, same as earlier scripts)
BUCKETS = [
    ("VERY SMALL", 12_000),   # 0 — 11 999
    ("SMALL"     , 30_000),   # 12 000 — 29 999
    ("MEDIUM"    , 50_000),   # 30 000 — 49 999
    ("LARGE"     , math.inf)  # 50 000+
]

def bucket_name(tok_count:int)->str:
    for name,limit in BUCKETS:
        if tok_count < limit:
            return name
    return "LARGE"   # never reached

# ─── ingest all run CSVs ───────────────────────────────────────────────
rows=[]
for csv_file in sorted(RUNS_DIR.rglob("experiment_summary.csv")):
    with csv_file.open() as f:
        rdr=csv.DictReader(f)
        rows.extend(rdr)

if not rows:
    print("No run CSVs found.  Run experiments first!")
    exit(0)

# convert numeric fields
num_keys=[k for k in rows[0] if k not in ("Case","Best Strategy")]
for row in rows:
    for k in num_keys:
        row[k]=float(row[k])

# ─── decide winners with margin logic ──────────────────────────────────
def winner(r):
    base = r["Wide Accuracy"]
    best = "Wide"
    if r["RAG Accuracy"]   - base > MARGIN:
        best,base = "RAG", r["RAG Accuracy"]
    if r["CLEAR Accuracy"] - base > MARGIN:
        best = "CLEAR"
    return best

for r in rows:
    r["Size Bucket"] = bucket_name(int(r["Note Tokens"]))
    r["Winner"]      = winner(r)

# ─── aggregate stats per bucket ────────────────────────────────────────
stats = {}
for name,_ in BUCKETS:
    group=[r for r in rows if r["Size Bucket"]==name]
    if not group: continue

    win_counts = Counter(r["Winner"] for r in group)
    avg_acc = {
        s: mean(r[f"{s} Accuracy"] for r in group)
        for s in ("Wide","RAG","CLEAR")
    }
    stats[name]={
        "#cases"  : len(group),
        "wins"    : (win_counts["Wide"],win_counts["RAG"],win_counts["CLEAR"]),
        "avg_acc" : (avg_acc["Wide"],avg_acc["RAG"],avg_acc["CLEAR"])
    }

# ─── pretty print ──────────────────────────────────────────────────────
def fmt_triplet(t): return " / ".join(f"{v:.3g}" if isinstance(v,float) else str(v)
                                      for v in t)

# ─── pretty print ──────────────────────────────────────────────────────
print("\n" + "="*80)
print("PERFORMANCE ANALYSIS BY NOTE SIZE")
print("="*80)

for b in ("VERY SMALL","SMALL","MEDIUM","LARGE"):
    if b not in stats: continue
    s = stats[b]
    
    print(f"\n📊 {b} NOTES ({s['#cases']} cases)")
    print("-" * 50)
    
    # Strategy performance table
    strategies = [
        ("Wide ", s['avg_acc'][0], s['wins'][0]),
        ("RAG  ", s['avg_acc'][1], s['wins'][1]), 
        ("CLEAR", s['avg_acc'][2], s['wins'][2])
    ]
    
    # Sort by score to show ranking
    strategies_sorted = sorted(strategies, key=lambda x: x[1], reverse=True)
    
    print("Strategy | Avg Score | Wins | Rank")
    print("---------|-----------|----- |-----")
    for i, (name, score, wins) in enumerate(strategies_sorted, 1):
        rank_emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉"
        print(f"{name}     |   {score:.3f}   |  {wins:2d}  | {i}{rank_emoji}")
    
    # Winner explanation
    best_score_strategy = strategies_sorted[0][0].strip()
    most_wins_strategy = max(strategies, key=lambda x: x[2])[0].strip()
    
    print(f"\n💡 Analysis:")
    print(f"   • Highest score: {best_score_strategy} ({strategies_sorted[0][1]:.3f})")
    print(f"   • Most wins: {most_wins_strategy} ({max(s['wins'])} wins)")
    
    if best_score_strategy != most_wins_strategy:
        score_diff = strategies_sorted[0][1] - strategies_sorted[1][1]
        print(f"   • Score leader wins by only {score_diff:.3f} (less than {MARGIN:.3f} margin)")
        print(f"   • Winner determined by margin rule: {most_wins_strategy}")
    else:
        print(f"   • Clear winner: {best_score_strategy}")

print("\n" + "="*80)
print("SUMMARY")
print("="*80)
print(f"Win Margin Threshold: {MARGIN:.3f} (strategy must beat others by this much)")
print("A strategy only 'wins' if it beats the baseline (Wide) by more than the margin.")
print("\n▶ Detailed results saved to aggregate_summary.json")

# ─── dump JSON snapshot ────────────────────────────────────────────────
out = {b:dict(stats[b]) for b in stats}
(Path(RUNS_DIR)/"aggregate_summary.json").write_text(
    json.dumps(out,indent=2))

print("\n▶ Summary saved to aggregate_summary.json")
