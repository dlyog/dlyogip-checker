#!/usr/bin/env python
"""
Utility for inspecting / fixing / extending individual synthetic
clinical notes.

USAGE
=====

# size audit
python expand_note.py check all
python expand_note.py check clinical_note7

# rebuild every state.json
python expand_note.py reset all

# grow an existing note by N years
python expand_note.py expand clinical_note7 25

# ✨ NEW: clone + extend in one shot
python expand_note.py clone clinical_note14 clinical_note15 40
"""
from __future__ import annotations
import sys, json, shutil, re, random, os
from pathlib import Path
import tiktoken
from dotenv import load_dotenv
from openai import OpenAI

# ────────────────────────────────────────────────────────────────────
load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
ENC = tiktoken.encoding_for_model("gpt-3.5-turbo")

BASE_YEAR = 1950          # first year if none in note yet
MAX_TOKENS_PER_YEAR = 700 # matches generate_notes_cli.py
SYS_MSG = "You are a clinical documentation LLM. Fill the {{ }} sections."
TEMPLATE = """
### Year: {year}
### Patient profile
{profile}

### Subjective (≤60 words)
{{subjective}}

### Objective / Vitals (≤80 words)
{{objective}}

### Labs & Imaging (≤80 words)
{labs}

### Assessment (≤80 words)
{{assessment}}

### Plan (≤80 words)
{{plan}}
""".strip()

# ────────────────────────── helpers ─────────────────────────────────
def tokens(txt: str) -> int:
    return len(ENC.encode(txt))

def find_last_year(note_text: str) -> int | None:
    yrs = [int(m.group(1)) for m in re.finditer(r'^--- (\d{4}) ---',
                                                note_text, flags=re.M)]
    return max(yrs) if yrs else None

def make_prompt(year: int, profile: str):
    return [
        {"role":"system","content":SYS_MSG},
        {"role":"user","content":TEMPLATE.format(
            year=year, profile=profile, labs="{labs}"
        )}
    ]

def gen_year(year: int, profile: str) -> str:
    rsp = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=make_prompt(year, profile),
        max_tokens=MAX_TOKENS_PER_YEAR,
        temperature=0.4
    )
    return rsp.choices[0].message.content.strip()

def note_dir(name:str)->Path:
    return Path("clinical_notes")/name

def load_state(p: Path)->dict|None:
    f=p/"state.json"
    if not f.exists(): return None
    try: return json.loads(f.read_text())
    except Exception: return None

def save_state(p:Path, yr_idx:int,toks:int,profile:str):
    (p/"state.json").write_text(json.dumps({
        "year_idx": yr_idx,
        "tokens": toks,
        "profile": profile
    }))

def rebuild_state_single(ndir:Path):
    note_txt=(ndir/"clinical_note.txt").read_text()
    tok_count=tokens(note_txt)
    last_year=find_last_year(note_txt)
    yrs = 0 if last_year is None else last_year-BASE_YEAR+1
    # profile line is always first line
    profile=re.search(r'^Patient profile: (.+)$',note_txt,flags=re.M)
    profile=profile.group(1).strip() if profile else "unknown"
    save_state(ndir,yrs,tok_count,profile)
    print(f"{ndir.name}: rebuilt state.json ({yrs} yrs, {tok_count:,} tokens)")

# ────────────────────────── commands ───────────────────────────────
def cmd_check(target:str):
    rows=[]
    dirs=[d for d in note_dir("").glob("clinical_note*") if d.is_dir()]
    sel=dirs if target=="all" else [note_dir(target)]
    for d in sel:
        st=load_state(d)
        tok=st["tokens"] if st else "?"
        rows.append((d.name,tok))
    w=max(len(n) for n,_ in rows)
    print("Note".ljust(w),"Tokens",sep="    ")
    print("─"*w,"──────",sep="    ")
    for n,t in rows:
        print(n.ljust(w),f"{t}" if isinstance(t,int) else t,sep="    ")

def cmd_reset(target:str):
    dirs=[d for d in note_dir("").glob("clinical_note*") if d.is_dir()]
    sel=dirs if target=="all" else [note_dir(target)]
    for d in sel:
        rebuild_state_single(d)

def cmd_expand(name:str, n_years:int):
    d=note_dir(name)
    st=load_state(d)
    if st is None:
        print(f"{name}: no valid state.json – run reset first"); return
    profile=st["profile"]
    year_idx=st["year_idx"]
    tok=st["tokens"]
    years_to_add=range(BASE_YEAR+year_idx,BASE_YEAR+year_idx+n_years)
    note_file=d/"clinical_note.txt"
    for yr in years_to_add:
        header=f"--- {yr} ---\n"
        txt=gen_year(yr,profile)
        with note_file.open("a") as f: f.write(header+txt+"\n\n")
        year_idx+=1
        tok+=tokens(header)+tokens(txt)
        save_state(d,year_idx,tok,profile)
        print(f"{name} · {yr} · {tok:,} tokens")
    print(f"✅ Finished {name}  ({tok:,} tokens)")

def cmd_clone(src:str, dst:str, n_years:int):
    src_dir = note_dir(src)
    dst_dir = note_dir(dst)
    if dst_dir.exists():
        print(f"{dst} already exists – abort."); return
    shutil.copytree(src_dir,dst_dir)
    print(f"Copied {src} ➜ {dst}")
    # reset + expand
    rebuild_state_single(dst_dir)
    cmd_expand(dst, n_years)

# ────────────────────────── main ───────────────────────────────────
def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    cmd=sys.argv[1]
    if cmd=="check":
        target=sys.argv[2]
        cmd_check(target)
    elif cmd=="reset":
        target=sys.argv[2]
        cmd_reset(target)
    elif cmd=="expand":
        name=sys.argv[2]; n=int(sys.argv[3])
        cmd_expand(name,n)
    elif cmd=="clone":
        src=sys.argv[2]; dst=sys.argv[3]; n=int(sys.argv[4])
        cmd_clone(src,dst,n)
    else:
        print("Unknown command"); sys.exit(1)

if __name__=="__main__":
    main()
