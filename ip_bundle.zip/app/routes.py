"""
Updated routes.py with authentication and data persistence
"""
import logging
import os
from datetime import datetime
from flask import Blueprint, request, jsonify, render_template, redirect, url_for, make_response, flash
from werkzeug.utils import secure_filename
from .admin_auth import get_system_setting
from .credit_utils import (get_user_credits, check_credits_available, use_credits,
                           is_generation_enabled, grant_credits, adjust_user_credits)
from .email_utils import send_capacity_reached_email
import json
from .admin_auth import get_system_setting

# Import your existing modules
from .vision import analyze_image
from .sonar import get_sonar_response, get_deep_research_analysis
from .utils import save_image
from .prompt import build_sonar_prompt

# Import new authentication and database modules
from .auth import (
    generate_verification_code, store_verification_code, verify_code,
    create_user, get_user_by_email, activate_user, 
    create_session_token, verify_session_token, invalidate_session
)
from .email_utils import send_verification_email, send_welcome_email
from .admin_email_utils import send_admin_verification_email
from .assessment_service import (
    save_assessment, update_assessment_final_report, 
    get_user_assessments, get_assessment_by_id, 
    get_assessment_stats, delete_assessment, extract_risk_rating
)

main = Blueprint("main", __name__, template_folder="templates")

# ---------------------------------------------------------------------- 
# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------- 
# Helper Functions

def get_current_user():
    """Get current user from session token"""
    token = request.cookies.get('auth_token')
    if token:
        from .auth import verify_session_token as auth_verify_session_token
        user_id = auth_verify_session_token(token)
        if user_id:
            user = get_user_by_email_from_id(user_id)
            return user
    return None

def get_user_by_email_from_id(user_id):
    """Helper to get user details by ID"""
    from .db_setup import get_db_connection
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, email, profile_image_path, is_active, created_at, updated_at FROM users WHERE id = %s",
                (user_id,)
            )
            result = cursor.fetchone()
            if result:
                return {
                    'id': result[0],
                    'email': result[1], 
                    'profile_image_path': result[2],
                    'is_active': result[3],
                    'created_at': result[4],  # Add this
                    'updated_at': result[5]   # Add this
                }
    except Exception as e:
        logger.error(f"Error getting user by ID: {e}")
    return None

def login_required(f):
    """Decorator to require authentication"""
    def decorated_function(*args, **kwargs):
        user = get_current_user()
        if not user:
            if request.is_json:
                return jsonify({'error': 'Authentication required'}), 401
            return redirect(url_for('main.login_page'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def save_profile_image(image_file):
    """Save uploaded profile image"""
    if not image_file:
        return None
    
    filename = secure_filename(image_file.filename)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    unique_name = f"profile_{timestamp}_{filename}"
    
    # Create profiles directory if it doesn't exist
    profile_dir = os.path.join("static", "profiles")
    os.makedirs(profile_dir, exist_ok=True)
    
    upload_path = os.path.join(profile_dir, unique_name)
    image_file.save(upload_path)
    return upload_path

# ---------------------------------------------------------------------- 
# Public Routes

@main.route("/", methods=["GET"])
def index():
    """Welcome page"""
    return render_template("index.html")

@main.route("/pricing", methods=["GET"])
def pricing():
    """pricing page"""
    return render_template("pricing.html")

@main.route("/signup", methods=["GET"])
def signup_page():
    """
    Signup page now shows capacity info.
    Provides:
      • active_users
      • max_users
      • remaining_slots
    """
    max_users = int(get_system_setting('general.max_users', 100000))
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM users WHERE is_active = TRUE")
        active_users = cur.fetchone()[0]

    return render_template(
        "signup.html",
        active_users     = active_users,
        max_users        = max_users,
        remaining_slots  = max(max_users - active_users, 0)
    )


@main.route("/login", methods=["GET"])
def login_page():
    """Login page"""
    return render_template("login.html")

@main.route("/architecture", methods=["GET"])
def architecture():
    """Login page"""
    return render_template("architecture.html")

@main.route("/logout", methods=["GET", "POST"])
def logout():
    """Logout user"""
    token = request.cookies.get('auth_token')
    if token:
        invalidate_session(token)
    
    response = make_response(redirect(url_for('main.index')))
    response.set_cookie('auth_token', '', expires=0)
    return response

# ---------------------------------------------------------------------- 
# Authentication Routes

import secrets
from datetime import datetime
from flask import session

def issue_slider_token() -> str:
    """Create a cryptographically-random token and remember it for this session."""
    token = secrets.token_urlsafe(16)        # 128-bit, url-safe
    session['slider_token'] = token          # store for later verification
    return token

def verify_slider_token(token: str) -> bool:
    """
    Accepts the token the browser sent.
    True  → token matches what we issued and hasn’t been reused.
    False → token missing, mismatched or replayed.
    """
    stored = session.pop('slider_token', None)   # pop = single-use
    if stored is None:
        return False
    return secrets.compare_digest(stored, token)

@main.route("/slider_token")
def slider_token():
    """Return a fresh slider token as plain text."""
    return issue_slider_token(), 200, {"Content-Type": "text/plain"}


@main.route("/signup/request", methods=["POST"])
def signup_request():
    """Handle signup request"""
    try:
        email = request.form.get('email', '').strip().lower()
        # --- Slider token verification ---
        slider_token = request.form.get('captcha_challenge', '')
        if not verify_slider_token(slider_token):
            flash("Please complete the verification slider to continue.", "error")
            return redirect(url_for('main.signup_page'))
        # --- /Slider token verification ---

        from .admin_auth import get_system_setting
        max_users = int(get_system_setting('general.max_users', 100000))
        with get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM users WHERE is_active = TRUE")
            current_users = cur.fetchone()[0]
        if current_users >= max_users:
            from .email_utils import send_capacity_reached_email
            send_capacity_reached_email(email, max_users)
            # store on wait-list
            with get_db_connection() as conn:
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO signup_waitlist (email) VALUES (%s) ON CONFLICT (email) DO NOTHING",
                    (email.lower(),)
                )
                conn.commit()

            flash('We appreciate your interest! The service is currently at capacity – please check back soon.', 'info')
            return redirect(url_for('main.signup_page'))
        # ----- /capacity gate -----


        # ----- capacity gate -----
        max_users = int(get_system_setting('general.max_users', 100000))
        with get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM users WHERE is_active = TRUE")
            current_users = cur.fetchone()[0]
        if current_users >= max_users:
            from .email_utils import send_capacity_reached_email
            send_capacity_reached_email(email, max_users)
            flash('We appreciate your interest! The service is currently at capacity – please check back soon.', 'info')
            return redirect(url_for('main.signup_page'))
        # ----- /capacity gate -----

        
        if not email:
            flash('Email is required', 'error')
            return redirect(url_for('main.signup_page'))
        
        # Check if user already exists
        existing_user = get_user_by_email(email)
        if existing_user and existing_user['is_active']:
            flash('Email already registered. Please login instead.', 'error')
            return redirect(url_for('main.login_page'))

        
        # Generate and send verification code
        code = generate_verification_code()
        if store_verification_code(email, code, 'signup'):
            if send_verification_email(email, code, 'signup'):
                return redirect(url_for('main.verify_page', email=email, purpose='signup'))
            else:
                flash('Error sending verification email. Please try again.', 'error')
        else:
            flash('Error generating verification code. Please try again.', 'error')
            
        return redirect(url_for('main.signup_page'))
        
    except Exception as e:
        logger.error(f"Signup error: {e}")
        flash('An error occurred. Please try again.', 'error')
        return redirect(url_for('main.signup_page'))

@main.route("/login/request", methods=["POST"])
def login_request():
    """Handle login request"""
    try:
        email = request.form.get('email', '').strip().lower()
        
        if not email:
            flash('Email is required', 'error')
            return redirect(url_for('main.login_page'))
        
        # Check if user exists and is active
        user = get_user_by_email(email)
        if not user or not user['is_active']:
            flash('Email not registered or not verified. Please sign up first.', 'error')
            return redirect(url_for('main.signup_page'))
        
        # Generate and send verification code
        code = generate_verification_code()
        if store_verification_code(email, code, 'login'):
            if send_verification_email(email, code, 'login'):
                return redirect(url_for('main.verify_page', email=email, purpose='login'))
            else:
                flash('Error sending login code. Please try again.', 'error')
        else:
            flash('Error generating login code. Please try again.', 'error')
            
        return redirect(url_for('main.login_page'))
        
    except Exception as e:
        logger.error(f"Login error: {e}")
        flash('An error occurred. Please try again.', 'error')
        return redirect(url_for('main.login_page'))


@main.route("/verify", methods=["GET", "POST"])
def verify_page():
    """Verification page"""
    if request.method == "GET":
        email = request.args.get('email')
        purpose = request.args.get('purpose')
        return render_template("verify.html", email=email, purpose=purpose)
    
    # POST - verify code
    if request.method == "POST":
        try:
            email = request.form.get('email', '').strip().lower()
            code = request.form.get('code', '').strip()
            purpose = request.form.get('purpose', '').strip()
            
            if not all([email, code, purpose]):
                flash('All fields are required', 'error')
                return redirect(url_for('main.verify_page', email=email, purpose=purpose))
            
            if verify_code(email, code, purpose):

                if purpose == 'signup':
                    # capacity re-check (handles parallel sign-ups finishing at same time)
                    max_users = int(get_system_setting('general.max_users', 100000))
                    with get_db_connection() as conn:
                        cur = conn.cursor()
                        cur.execute("SELECT COUNT(*) FROM users WHERE is_active = TRUE")
                        current_users = cur.fetchone()[0]
                    if current_users >= max_users:
                        from .email_utils import send_capacity_reached_email
                        send_capacity_reached_email(email, max_users)
                        # store on wait-list
                        with get_db_connection() as conn:
                            cur = conn.cursor()
                            cur.execute(
                                "INSERT INTO signup_waitlist (email) VALUES (%s) ON CONFLICT (email) DO NOTHING",
                                (email.lower(),)
                            )
                            conn.commit()

                        flash('The platform is temporarily full. We will notify you once new slots open.', 'error')
                        return redirect(url_for('main.signup_page'))

                    # For signup: Create and activate user
                    user = get_user_by_email(email)
                    if not user:
                        # User doesn't exist, create them
                        user_id = create_user(email, None, True)  # Create active user
                        if not user_id:
                            flash('Error creating account. Please try again.', 'error')
                            return redirect(url_for('main.signup_page'))
                        
                        # Get the newly created user
                        user = get_user_by_email(email)
                    else:
                        # User exists but wasn't active, activate them
                        activate_user(email)
                    
                    send_welcome_email(email)
                
                elif purpose == 'login':
                    # For login: User should already exist
                    user = get_user_by_email(email)
                    if not user:
                        flash('User not found', 'error')
                        return redirect(url_for('main.login_page'))
                    
                    if not user['is_active']:
                        flash('Account not activated. Please contact support.', 'error')
                        return redirect(url_for('main.login_page'))
                
                # At this point, user should exist for both signup and login
                if not user:
                    flash('Error processing request. Please try again.', 'error')
                    return redirect(url_for('main.signup_page'))
                
                # Create session token
                token = create_session_token(user['id'])
                response = make_response(redirect(url_for('main.dashboard')))
                response.set_cookie(
                    'auth_token',
                    token,
                    max_age=60 * 60 * 24 * 21,  # 21 days
                    httponly=True,
                    secure=False,  # Set to True in production with HTTPS
                    samesite='Lax'
                )
                
                if purpose == 'signup':
                    flash('Account created successfully! Welcome to FlameGuardAI!', 'success')
                else:
                    flash('Successfully logged in!', 'success')
                
                return response
            else:
                flash('Invalid or expired verification code', 'error')
                return redirect(url_for('main.verify_page', email=email, purpose=purpose))
                
        except Exception as e:
            logger.error(f"Verification error: {e}")
            flash('An error occurred. Please try again.', 'error')
            return redirect(url_for('main.verify_page', email=request.form.get('email'), purpose=request.form.get('purpose')))
# ---------------------------------------------------------------------- 
# Protected Routes

@main.route("/dashboard", methods=["GET"])
@login_required
def dashboard():
    """User dashboard"""
    user = get_current_user()
    # Get user credits
    credits = get_user_credits(user['id'])
    assessments = get_user_assessments(user['id'], limit=10)
    stats = get_assessment_stats(user['id'])
    return render_template("dashboard.html", user=user, credits=credits, assessments=assessments, stats=stats)

@main.route("/api/user/credits", methods=["GET"])
@login_required
def api_get_user_credits():
    """Get current user's credit balance"""
    try:
        user = get_current_user()
        credits = get_user_credits(user['id'])
        return jsonify(credits)
    except Exception as e:
        logger.error(f"Error getting user credits: {e}")
        return jsonify({"error": "Failed to get credits"}), 500
    
@main.route("/assessment", methods=["GET"])
@login_required
def assessment_page():
    """Fire risk assessment page"""
    user = get_current_user()
    # Get user credits
    credits = get_user_credits(user['id'])
    assessments = get_user_assessments(user['id'], limit=10)
    stats = get_assessment_stats(user['id'])
    return render_template("report.html", user=user, credits=credits, assessments=assessments, stats=stats)
    

@main.route("/assessments", methods=["GET"])
@login_required 
def assessments_list():
    """List user's assessments"""
    user = get_current_user()
    page = int(request.args.get('page', 1))
    limit = 20
    offset = (page - 1) * limit
    
    assessments = get_user_assessments(user['id'], limit=limit, offset=offset)
    # Get user credits
    credits = get_user_credits(user['id'])
    stats = get_assessment_stats(user['id'])
    return render_template("assessments.html", user=user, credits=credits, assessments=assessments, stats=stats, page=page)

@main.route("/assessment/<int:assessment_id>", methods=["GET"])
@login_required
def view_assessment(assessment_id):
    """View specific assessment"""
    user = get_current_user()
    assessment = get_assessment_by_id(assessment_id, user['id'])
    
    if not assessment:
        flash('Assessment not found', 'error')
        return redirect(url_for('main.assessments_list'))
    
    # Get user credits
    credits = get_user_credits(user['id'])
    stats = get_assessment_stats(user['id'])
    
    return render_template("assessment_detail.html", user=user, credits=credits, stats=stats, assessment=assessment)

@main.route("/assessment/<int:assessment_id>/delete", methods=["POST"])
@login_required
def delete_assessment_route(assessment_id):
    """Delete assessment"""
    user = get_current_user()
    
    if delete_assessment(assessment_id, user['id']):
        flash('Assessment deleted successfully', 'success')
    else:
        flash('Error deleting assessment', 'error')
    
    return redirect(url_for('main.assessments_list'))

# ---------------------------------------------------------------------- 
# API Routes (Updated with Authentication)

@main.route("/api/analyze", methods=["POST"])
@login_required
def api_analyze():
    """
    Receive uploaded image → run Vision model → return summary & detail.
    Now saves to database for authenticated users.
    """
    try:
        user = get_current_user()
        image = request.files["image"]
        zip_code = request.form.get("zip_code", "")
        state = request.form.get("state", "CA")

        # Check if generation is enabled globally
        if not is_generation_enabled():
            return jsonify({
                "error": "Assessment generation is temporarily disabled. Please try again later.",
                "error_type": "generation_disabled"
            }), 503

        # Check if user has credits
        has_credits, message = check_credits_available(user['id'])
        if not has_credits:
            return jsonify({
                "error": message,
                "error_type": "insufficient_credits",
                "credits_available": 0
            }), 403
        
        # Save image
        filepath = save_image(image)
        logger.info("Saved uploaded image to %s", filepath)

        # Analyze image
        analysis = analyze_image(filepath)
        logger.info("Vision analysis result: %s", analysis)

        # Check if the analysis failed validation
        if analysis.get("status") != "Success":
            # Return the validation failure response directly
            return jsonify({
                "status": analysis.get("status", "Error"),
                "summary": analysis.get("summary", ""),
                "detail_response": analysis.get("detail_response", "")
            })

        # If analysis was successful, save to database and proceed
        assessment_id = save_assessment(
            user_id=user['id'],
            image_path=filepath,
            zip_code=zip_code,
            state=state,
            user_context="",  # Will be updated later
            vision_summary=analysis.get("summary", ""),
            vision_detail=analysis.get("detail_response", "")
        )

        # Return successful response with status included
        return jsonify({
            "status": analysis.get("status", "Success"),  # FIXED: Include status
            "assessment_id": assessment_id,
            "summary": analysis.get("summary", ""),
            "detail": analysis.get("detail_response", ""),  # Keep 'detail' for backward compatibility
            "detail_response": analysis.get("detail_response", "")  # Also include detail_response
        })
        
    except Exception as exc:
        logger.exception("Error during image analysis")
        return jsonify({
            "status": "Error",  # FIXED: Include status for errors
            "summary": "Image analysis failed.",
            "detail": str(exc),
        }), 500

@main.route("/api/report", methods=["POST"])
@login_required 
def api_report():
    """
    Build Sonar prompt from Vision detail + user context, call Sonar,
    and return a clean JSON payload. Updates the assessment in database.
    """
    try:
        user = get_current_user()
        data = request.get_json()
                
        assessment_id = data.get("assessment_id")
        detail = data.get("detail", "")
        user_ctx = data.get("context", "")
        zip_code = data.get("zip", "")
        state = data.get("state", "CA")
        
        # NEW: Check if deep research is requested (optional parameter)
        use_deep_research = data.get("deep_research", False)

        full_ctx = f"{detail}\n{user_ctx}"
        
        # NEW: Choose between deep research or existing method
        if use_deep_research:
            # Use the new deep research system
            result = get_deep_research_analysis(detail, zip_code, state, user_ctx)
            # Extract the main response for compatibility
            final_result = {
                "summary": result.get("summary", ""),
                "detail_response": result.get("detail_response", ""),
                "research_data": result.get("research_data", {})  # NEW: Additional research data
            }
        else:
            # Use existing system (backward compatibility)
            prompt = build_sonar_prompt(full_ctx, zip_code, state)
            logger.info("Sonar prompt: %s", prompt)
            final_result = get_sonar_response(prompt)
            logger.info("Sonar response dict: %s", final_result)

        # Extract risk rating from the final detail (existing logic unchanged)
        risk_rating = extract_risk_rating(final_result.get("detail_response", ""))

        # Update assessment with final report (existing logic unchanged)
        if assessment_id:
            success = update_assessment_final_report(
                assessment_id=assessment_id,
                final_summary=final_result.get("summary", ""),
                final_detail=final_result.get("detail_response", ""),
                risk_rating=risk_rating
            )
                        
            # Also update user context (existing logic unchanged)
            from .db_setup import get_db_connection
            try:
                with get_db_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute(
                        "UPDATE assessments SET user_context = %s WHERE id = %s AND user_id = %s",
                        (user_ctx, assessment_id, user['id'])
                    )
                    conn.commit()
            except Exception as e:
                logger.error(f"Error updating user context: {e}")

        # Return response with optional deep research data
        response_data = {
            "assessment_id": assessment_id,
            "summary": final_result.get("summary", ""),
            "detail": final_result.get("detail_response", ""),
            "risk_rating": risk_rating,
            "has_detailed_report": use_deep_research,  # NEW: Flag for frontend
        }

        # NEW: Add research data if deep research was used
        if use_deep_research and "research_data" in final_result:
            response_data["research_data"] = final_result["research_data"]

        # NEW: Send email notification for comprehensive assessments
        if use_deep_research and assessment_id:
            try:
                from .email_utils import send_assessment_complete_email
                
                # Get user's name (optional, can be None)
                user_name = user.get('name') or user.get('email', '').split('@')[0]
                
                # Send email notification
                email_sent = send_assessment_complete_email(
                    email=user['email'],
                    user_name=user_name,
                    assessment_id=assessment_id,
                    risk_rating=risk_rating,
                    summary=final_result.get("summary", "")
                )
                
                if email_sent:
                    logger.info(f"Assessment complete email sent to {user['email']} for assessment {assessment_id}")
                else:
                    logger.warning(f"Failed to send assessment complete email to {user['email']}")
                    
            except Exception as e:
                logger.error(f"Error sending assessment complete email: {e}")
                # Don't fail the entire request if email fails

        return jsonify(response_data)
        
    except Exception as exc:
        logger.exception("Error during report generation")
        return jsonify({
            "summary": "Report generation failed.",
            "detail": str(exc),
        }), 500

@main.route("/api/detailed-report", methods=["POST"])
@login_required 
def get_detailed_report():
    """
    Return detailed HTML report for popup display
    """
    try:
        data = request.get_json()
        report_data = data.get("report_data", "")
        
        # If report_data contains HTML, return it directly
        if "<html>" in report_data.lower() or "<div>" in report_data.lower():
            return jsonify({
                "html_content": report_data,
                "success": True
            })
        else:
            # Convert plain text to basic HTML
            report_data_html = report_data.replace('\n', '<br>')
            html_content = f"""
                <div class="detailed-report">
                    <div class="report-content">
                        {report_data_html}
                    </div>
                </div>
            """
            return jsonify({
                "html_content": html_content,
                "success": True
            })
            
    except Exception as e:
        return jsonify({
            "html_content": f"<div class='error'>Error loading detailed report: {str(e)}</div>",
            "success": False
        }), 500


# ---------------------------------------------------------------------- 
# Backwards Compatibility Route (for testing without auth)

@main.route("/test", methods=["GET"])
def test_page():
    """Test page for backwards compatibility - works without authentication"""
    return render_template("report.html")

@main.route("/api/test/analyze", methods=["POST"])
def api_test_analyze():
    """Test analyze endpoint without authentication (for development)"""
    try:
        image = request.files["image"]
        filepath = save_image(image)
        logger.info("Saved uploaded image to %s", filepath)

        analysis = analyze_image(filepath)
        logger.info("Vision analysis result: %s", analysis)

        return jsonify({
            "summary": analysis.get("summary", ""),
            "detail": analysis.get("detail_response", ""),
        })
    except Exception as exc:
        logger.exception("Error during image analysis")
        return jsonify({
            "summary": "Image analysis failed.",
            "detail": str(exc),
        }), 500

@main.route("/api/test/report", methods=["POST"])
def api_test_report():
    """Test report endpoint without authentication (for development)"""
    try:
        data = request.get_json()
        detail = data.get("detail", "")
        user_ctx = data.get("context", "")
        zip_code = data.get("zip", "")
        state = data.get("state", "CA")

        full_ctx = f"{detail}\n{user_ctx}"
        prompt = build_sonar_prompt(full_ctx, zip_code, state)

        logger.info("Sonar prompt: %s", prompt)
        result = get_sonar_response(prompt)
        logger.info("Sonar response dict: %s", result)

        return jsonify({
            "summary": result.get("summary", ""),
            "detail": result.get("detail_response", ""),
        })
    except Exception as exc:
        logger.exception("Error during report generation")
        return jsonify({
            "summary": "Report generation failed.",
            "detail": str(exc),
        }), 500

# Add these API endpoints to your routes.py

@main.route("/api/assessments", methods=["GET"])
@login_required
def api_get_assessments():
    """Get user's assessments via AJAX"""
    try:
        user = get_current_user()
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        offset = (page - 1) * limit
        
        assessments = get_user_assessments(user['id'], limit=limit, offset=offset)
        
        # Convert datetime objects to strings for JSON serialization
        assessments_json = []
        for assessment in assessments:
            assessment_dict = dict(assessment)
            if assessment_dict.get('created_at'):
                assessment_dict['created_at'] = assessment_dict['created_at'].isoformat()
            if assessment_dict.get('updated_at'):
                assessment_dict['updated_at'] = assessment_dict['updated_at'].isoformat()
            assessments_json.append(assessment_dict)
        
        return jsonify({
            "assessments": assessments_json,
            "page": page,
            "has_more": len(assessments) == limit
        })
    except Exception as e:
        logger.error(f"Error getting assessments: {e}")
        return jsonify({"error": "Failed to load assessments"}), 500

@main.route("/api/assessment/<int:assessment_id>/delete", methods=["DELETE"])
@login_required
def api_delete_assessment(assessment_id):
    """Delete assessment via AJAX"""
    try:
        user = get_current_user()
        success = delete_assessment(assessment_id, user['id'])
        
        if success:
            return jsonify({"message": "Assessment deleted successfully"})
        else:
            return jsonify({"error": "Assessment not found or access denied"}), 404
            
    except Exception as e:
        logger.error(f"Error deleting assessment: {e}")
        return jsonify({"error": "Failed to delete assessment"}), 500

@main.route("/api/assessment/<int:assessment_id>", methods=["GET"])
@login_required
def api_get_assessment(assessment_id):
    """Get single assessment details via AJAX"""
    try:
        user = get_current_user()
        assessment = get_assessment_by_id(assessment_id, user['id'])
        
        if not assessment:
            return jsonify({"error": "Assessment not found"}), 404
        
        # Convert datetime objects to strings for JSON serialization
        if assessment.get('created_at'):
            assessment['created_at'] = assessment['created_at'].isoformat()
        if assessment.get('updated_at'):
            assessment['updated_at'] = assessment['updated_at'].isoformat()
        
        return jsonify(assessment)
        
    except Exception as e:
        logger.error(f"Error getting assessment {assessment_id}: {e}")
        return jsonify({"error": "Failed to load assessment"}), 500

@main.route("/api/user/delete-account", methods=["DELETE"])
@login_required
def api_delete_account():
    """Delete user account and all associated data"""
    try:
        user = get_current_user()
        user_id = user['id']
        
        # Get all assessment image paths before deletion for cleanup
        image_paths = []
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT image_path FROM assessments WHERE user_id = %s", (user_id,))
            image_paths = [row[0] for row in cursor.fetchall()]
        
        # Delete all user data in correct order (due to foreign key constraints)
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            # Delete user sessions
            cursor.execute("DELETE FROM user_sessions WHERE user_id = %s", (user_id,))
            
            # Delete assessments (will cascade delete is handled by DB)
            cursor.execute("DELETE FROM assessments WHERE user_id = %s", (user_id,))
            
            # Delete verification codes
            cursor.execute("DELETE FROM verification_codes WHERE email = %s", (user['email'],))
            
            # Delete user profile image if exists
            if user.get('profile_image_path') and os.path.exists(user['profile_image_path']):
                try:
                    os.remove(user['profile_image_path'])
                except Exception as e:
                    logger.warning(f"Could not delete profile image: {e}")
            
            # Delete the user account
            cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
            
            conn.commit()
        
        # Clean up assessment images
        for image_path in image_paths:
            try:
                if image_path and os.path.exists(image_path):
                    os.remove(image_path)
            except Exception as e:
                logger.warning(f"Could not delete assessment image {image_path}: {e}")
        
        logger.info(f"User account {user_id} ({user['email']}) deleted successfully")
        
        return jsonify({
            "message": "Account deleted successfully",
            "deleted_assessments": len(image_paths)
        })
        
    except Exception as e:
        logger.error(f"Error deleting user account: {e}")
        return jsonify({"error": "Failed to delete account"}), 500
    
@main.route("/api/user/profile", methods=["GET"])
@login_required
def api_get_user_profile():
    """Get current user profile"""
    try:
        user = get_current_user()
        
        # Better date formatting
        if user.get('created_at'):
            if hasattr(user['created_at'], 'isoformat'):
                user['created_at'] = user['created_at'].isoformat()
            else:
                user['created_at'] = str(user['created_at'])
                
        if user.get('updated_at'):
            if hasattr(user['updated_at'], 'isoformat'):
                user['updated_at'] = user['updated_at'].isoformat()
            else:
                user['updated_at'] = str(user['updated_at'])
            
        return jsonify(user)
    except Exception as e:
        logger.error(f"Error getting user profile: {e}")
        return jsonify({"error": "Failed to load profile"}), 500

@main.route("/api/user/stats", methods=["GET"])
@login_required
def api_get_user_stats():
    """Get user account statistics"""
    try:
        user = get_current_user()
        stats = get_assessment_stats(user['id'])
        
        # Calculate account age
        from datetime import datetime
        if user.get('created_at'):
            created_date = user['created_at']
            if isinstance(created_date, str):
                created_date = datetime.fromisoformat(created_date)
            account_age = (datetime.now() - created_date).days
            stats['account_age_days'] = account_age
        
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Error getting user stats: {e}")
        return jsonify({"error": "Failed to load stats"}), 500

@main.route("/account-settings", methods=["GET"])
@login_required
def account_settings_page():
    """Account settings page"""

    user = get_current_user()
    # Get user credits
    credits = get_user_credits(user['id'])
    assessments = get_user_assessments(user['id'], limit=10)
    stats = get_assessment_stats(user['id'])
    return render_template("account_settings.html", user=user, credits=credits, assessments=assessments, stats=stats)
    

# Add these imports at the top
from .admin_auth import (
    create_admin_user, get_admin_by_email,
    create_admin_session_token, verify_admin_session_token, 
    generate_admin_verification_code, store_admin_verification_code,
    verify_admin_code, log_admin_activity
)

from .admin_auth import (
    get_all_users, get_user_details, block_user, unblock_user,
    delete_user_account, get_user_statistics
)


# Admin authentication decorator
def admin_required(f):
    """Decorator to require admin authentication"""
    def decorated_function(*args, **kwargs):
        token = request.cookies.get('admin_token')
        if not token:
            if request.is_json:
                return jsonify({'error': 'Admin authentication required'}), 401
            return redirect(url_for('main.admin_login_page'))
        
        admin_id = verify_admin_session_token(token)
        if not admin_id:
            if request.is_json:
                return jsonify({'error': 'Invalid admin session'}), 401
            return redirect(url_for('main.admin_login_page'))
        
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def get_current_admin():
    """Get current admin from session token"""
    token = request.cookies.get('admin_token')
    if token:
        admin_id = verify_admin_session_token(token)
        if admin_id:
            admin = get_admin_by_id(admin_id)  # You'll need this function
            return admin
    return None

# ---------------------------------------------------------------------- 
# Admin Authentication Routes

@main.route("/admin", methods=["GET"])
def admin_login_page():
    """Admin login page"""
    return render_template("admin_login.html")

@main.route("/admin/login", methods=["POST"])
def admin_login():
    """Handle admin login"""
    try:
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        
        if not email or not password:
            flash('Email and password are required', 'error')
            return redirect(url_for('main.admin_login_page'))
        
        # Verify admin credentials
        admin = get_admin_by_email(email)
        if not admin or not verify_admin_password(password, admin['password_hash']):
            flash('Invalid email or password', 'error')
            return redirect(url_for('main.admin_login_page'))
        
        if not admin['is_active']:
            flash('Admin account is disabled', 'error')
            return redirect(url_for('main.admin_login_page'))
        
        # Create session token
        token = create_admin_session_token(admin['id'])
        response = make_response(redirect(url_for('main.admin_dashboard')))
        response.set_cookie(
            'admin_token',
            token,
            max_age=60 * 60 * 8,  # 8 hours
            httponly=True,
            secure=False,  # Set to True in production with HTTPS
            samesite='Lax'
        )
        
        # Log admin login
        log_admin_activity(admin['id'], 'admin_login', 'auth', None, {
            'ip_address': request.remote_addr,
            'user_agent': request.headers.get('User-Agent')
        })
        
        flash('Successfully logged in!', 'success')
        return response
        
    except Exception as e:
        logger.error(f"Admin login error: {e}")
        flash('An error occurred. Please try again.', 'error')
        return redirect(url_for('main.admin_login_page'))

@main.route("/admin/logout", methods=["GET", "POST"])
def admin_logout():
    """Admin logout"""
    token = request.cookies.get('admin_token')
    if token:
        # You may want to invalidate the token in database
        pass
    
    response = make_response(redirect(url_for('main.admin_login_page')))
    response.set_cookie('admin_token', '', expires=0)
    return response

# ---------------------------------------------------------------------- 
# Admin Dashboard Routes

@main.route("/admin/dashboard", methods=["GET"])
@admin_required
def admin_dashboard():
    """Admin dashboard"""
    return render_template("admin_dashboard.html")



@main.route("/admin/users", methods=["GET"])
@admin_required
def admin_users():
    """
    Admin users management page – now passes:
      • stats   → get_user_statistics()
      • settings→ {'general': {'max_users': …}}
    so the template can render {{ stats.total_users }} etc.
    """
    stats      = get_user_statistics()
    max_users  = int(get_system_setting('general.max_users', 100000))
    settings   = {'general': {'max_users': max_users}}

    return render_template("admin_users.html",
                           stats=stats,
                           settings=settings)


@main.route("/admin/verify", methods=["GET"])
def admin_verify_page():
    """Admin verification page"""
    return render_template("admin_verify.html")

# ---------------------------------------------------------------------- 
# Admin API Routes

@main.route("/api/admin/stats", methods=["GET"])
@admin_required
def api_admin_stats():
    """Get admin dashboard statistics"""
    try:
        stats = get_user_statistics()
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Error getting admin stats: {e}")
        return jsonify({"error": "Failed to load statistics"}), 500

@main.route("/api/admin/users", methods=["GET"])
@admin_required
def api_admin_get_users():
    """Get all users for admin management"""
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        search = request.args.get('search', '')
        status_filter = request.args.get('status', 'all')
        
        result = get_all_users(page=page, limit=limit, search=search, status_filter=status_filter)
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error getting users for admin: {e}")
        return jsonify({"error": "Failed to load users"}), 500

@main.route("/api/admin/user/<int:user_id>", methods=["GET"])
@admin_required
def api_admin_get_user_details(user_id):
    """Get detailed user information"""
    try:
        user_details = get_user_details(user_id)
        if not user_details:
            return jsonify({"error": "User not found"}), 404
            
        return jsonify(user_details)
        
    except Exception as e:
        logger.error(f"Error getting user details {user_id}: {e}")
        return jsonify({"error": "Failed to load user details"}), 500

@main.route("/api/admin/user/<int:user_id>/block", methods=["POST"])
@admin_required
def api_admin_block_user(user_id):
    """Block a user account"""
    try:
        admin = get_current_admin()
        data = request.get_json()
        reason = data.get('reason', 'No reason provided')
        
        success = block_user(user_id, reason, admin['id'])
        
        if success:
            return jsonify({"message": "User blocked successfully"})
        else:
            return jsonify({"error": "Failed to block user"}), 400
            
    except Exception as e:
        logger.error(f"Error blocking user {user_id}: {e}")
        return jsonify({"error": "Failed to block user"}), 500


# POST /admin/api/credits/revoke
@main.route("/admin/api/credits/revoke", methods=["POST"])
@admin_required
def api_admin_revoke_credits():
    data   = request.get_json() or {}
    uid    = int(data.get("user_id", 0))
    amount = int(data.get("amount", 0))
    ctype  = data.get("credit_type", "free")
    desc   = data.get("description", "")

    admin  = get_current_admin()

    if amount < 1:
        return jsonify({"error": "amount must be ≥1"}), 400

    ok = adjust_user_credits(
            user_id=uid,
            amount=-amount,               # negative = remove
            credit_type=ctype,
            description=desc,
            admin_id=admin["id"],
            force_type="admin_revoke"
        )
    if ok:
        return jsonify({"message": f"Removed up to {amount} {ctype} credits"})
    return jsonify({"error": "revoke failed"}), 500



@main.route("/api/admin/user/<int:user_id>/unblock", methods=["POST"])
@admin_required
def api_admin_unblock_user(user_id):
    """Unblock a user account"""
    try:
        admin = get_current_admin()
        success = unblock_user(user_id, admin['id'])
        
        if success:
            return jsonify({"message": "User unblocked successfully"})
        else:
            return jsonify({"error": "Failed to unblock user"}), 400
            
    except Exception as e:
        logger.error(f"Error unblocking user {user_id}: {e}")
        return jsonify({"error": "Failed to unblock user"}), 500

@main.route("/api/admin/user/<int:user_id>/delete", methods=["DELETE"])
@admin_required
def api_admin_delete_user(user_id):
    """Delete a user account (admin action)"""
    try:
        admin = get_current_admin()
        success = delete_user_account(user_id, admin['id'])
        
        if success:
            return jsonify({"message": "User account deleted successfully"})
        else:
            return jsonify({"error": "Failed to delete user account"}), 400
            
    except Exception as e:
        logger.error(f"Error deleting user {user_id}: {e}")
        return jsonify({"error": "Failed to delete user account"}), 500
    
@main.route("/admin/api/credits/grant", methods=["POST"])
@admin_required
def api_admin_grant_credits():
    """
    JSON body → {user_id, amount, credit_type: "free"|"purchased", description?}
    Grants credits and records the transaction.
    """
    try:
        admin = get_current_admin()
        data = request.get_json(force=True) or {}

        user_id   = int(data.get("user_id", 0))
        amount    = int(data.get("amount",   0))
        ctype     =      data.get("credit_type", "free")
        desc      =      data.get("description", "")

        if user_id < 1 or amount < 1 or ctype not in ("free", "purchased"):
            return jsonify({"error": "Invalid parameters"}), 400

        if grant_credits(user_id, amount, ctype, desc, admin["id"]):
            # optional: log_admin_activity(admin['id'], 'credits_granted', 'user', user_id, {"amount": amount, "type": ctype})
            return jsonify({"message": f"{amount} {ctype} credits granted"}), 200

        return jsonify({"error": "Grant operation failed"}), 400

    except Exception as e:
        logger.error(f"Admin grant credits error: {e}")
        return jsonify({"error": "Internal server error"}), 500



def get_admin_by_id(admin_id):
    """Helper to get admin details by ID"""
    from .admin_db_setup import get_admin_db_connection  # You'll need this
    try:
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                    "SELECT id, email, is_active FROM admin_users WHERE id = %s",
                    (admin_id,)
            )
            result = cursor.fetchone()
            if result:
                return {
                    'id': result[0],
                    'email': result[1],
                    'is_active': result[2]
                }

    except Exception as e:
        logger.error(f"Error getting admin by ID: {e}")
    return None

@main.route("/admin/login/request", methods=["POST"])
def admin_login_request():
    """
    Accepts POST with email, sends a verification code to admin's email.
    """
    data = request.get_json()
    email = (data.get('email') or '').strip().lower()
    if not email:
        return jsonify({'error': 'Email is required'}), 400

    admin = get_admin_by_email(email)
    if not admin or not admin.get('is_active', True):
        return jsonify({'error': 'Unauthorized or inactive admin'}), 403

    code = generate_admin_verification_code()
    purpose = 'login'
    if not store_admin_verification_code(email, code, purpose):
        return jsonify({'error': 'Could not generate code'}), 500

    # Send code via email (your admin_email_utils)
    send_admin_verification_email(email, code, purpose)
    return jsonify({'message': 'Verification code sent'}), 200

@main.route("/admin/verify", methods=["POST"])
def admin_verify_code():
    """
    Accepts POST with email + code, verifies code, logs in admin.
    Returns session cookie and redirects to dashboard.
    """
    data = request.get_json()
    email = (data.get('email') or '').strip().lower()
    code = (data.get('code') or '').strip()
    purpose = 'login'

    if not email or not code or len(code) != 6:
        return jsonify({'error': 'Email and 6-digit code required'}), 400

    admin = get_admin_by_email(email)
    if not admin or not admin.get('is_active', True):
        return jsonify({'error': 'Unauthorized or inactive admin'}), 403

    if not verify_admin_code(email, code, purpose):
        return jsonify({'error': 'Invalid or expired verification code'}), 401

    # Create session token
    token = create_admin_session_token(admin['id'])

    response = jsonify({'message': 'Logged in'})
    response.set_cookie(
        'admin_token',
        token,
        max_age=60 * 60 * 8,  # 8 hours
        httponly=True,
        secure=False,          # Set to True in production with HTTPS
        samesite='Lax'
    )

    # Optionally log activity here
    log_admin_activity(admin['id'], 'admin_login', 'auth', None, {
        'ip_address': request.remote_addr,
        'user_agent': request.headers.get('User-Agent')
    })

    return response, 200

# You can adjust @main.route to @admin.route if you use a Blueprint, but keep the URL paths as required

from flask import jsonify, request
from flask import g  # If you use g for session
from .admin_auth import (
    get_admin_by_id, get_user_statistics, log_admin_activity
)
from .admin_db_setup import get_admin_db_connection

from functools import wraps

# (Re-use your admin_required decorator from before)
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = request.cookies.get('admin_token')
        if not token:
            return jsonify({'error': 'Admin authentication required'}), 401
        admin_id = verify_admin_session_token(token)
        if not admin_id:
            return jsonify({'error': 'Invalid admin session'}), 401
        g.admin_id = admin_id
        return f(*args, **kwargs)
    return decorated_function

# 1. Admin profile (GET /admin/api/profile)
@main.route("/admin/api/profile", methods=["GET"])
@admin_required
def api_admin_profile():
    admin = get_admin_by_id(g.admin_id)
    if not admin:
        return jsonify({"error": "Admin not found"}), 404
    # Optionally update last_login
    try:
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE admin_users SET last_login = NOW() WHERE id = %s", (admin['id'],))
            conn.commit()
    except Exception:
        pass
    return jsonify({
        "id": admin["id"],
        "email": admin["email"],
        "last_login": admin.get("last_login")
    })

# 2. Dashboard statistics (GET /admin/api/statistics)
@main.route("/admin/api/statistics", methods=["GET"])
@admin_required
def api_admin_statistics():
    stats = get_user_statistics()
    return jsonify(stats)

# 3. Recent admin activity (GET /admin/api/activity/recent)
@main.route("/admin/api/activity/recent", methods=["GET"])
@admin_required
def api_admin_activity_recent():
    # Show last 10 actions, can expand as needed
    try:
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT id, admin_id, action, target_type, target_id, details, ip_address, user_agent, created_at
                FROM admin_activity_log
                ORDER BY created_at DESC
                LIMIT 10
                """
            )
            activities = []
            for row in cursor.fetchall():
                activities.append({
                    "id": row[0],
                    "admin_id": row[1],
                    "action": row[2],
                    "target_type": row[3],
                    "target_id": row[4],
                    "details": row[5] if isinstance(row[5], dict) else None,
                    "ip_address": row[6],
                    "user_agent": row[7],
                    "created_at": row[8].isoformat() if row[8] else None
                })
            return jsonify({"activities": activities})
    except Exception as e:
        return jsonify({"activities": []})

# 4. Active prompts (GET /admin/api/prompts/active)
@main.route("/admin/api/prompts/active", methods=["GET"])
@admin_required
def api_admin_prompts_active():
    try:
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            # Get all active prompts
            cursor.execute("""
                SELECT prompt_key, prompt_name, version as active_version
                FROM prompts
                WHERE is_active = TRUE
            """)
            prompts = []
            for row in cursor.fetchall():
                prompts.append({
                    "prompt_key": row[0],
                    "prompt_name": row[1],
                    "active_version": row[2]
                })
            return jsonify({"prompts": prompts})
    except Exception as e:
        return jsonify({"prompts": []})

# 5. User list (GET /admin/api/users)
@main.route("/admin/api/users", methods=["GET"])
@admin_required
def api_admin_users():
    page = int(request.args.get('page', 1))
    limit = int(request.args.get('limit', 20))
    search = request.args.get('search', '')
    status_filter = request.args.get('status', 'all')
    result = get_all_users(page=page, limit=limit, search=search, status_filter=status_filter)
    return jsonify(result)


from flask import request, jsonify, render_template

from .admin_prompts import (
    get_prompts_all, get_active_prompts, get_prompt_versions,
    create_prompt, add_prompt_version, update_prompt_active, delete_prompt_version
)

# Admin UI Page
@main.route("/admin/prompts", methods=["GET"])
@admin_required
def admin_prompts_page():
    """Prompt management page (UI)"""
    return render_template("admin_prompts.html")

# --- API Endpoints ---

@main.route("/admin/api/prompts/all", methods=["GET"])
@admin_required
def api_prompts_all():
    """Get all prompt keys and versions"""
    return jsonify(get_prompts_all())

@main.route("/admin/api/prompts/active", methods=["GET"])
@admin_required
def api_prompts_active():
    """Get active prompts (dashboard)"""
    return jsonify({"prompts": get_active_prompts()})

@main.route("/admin/api/prompts/<prompt_key>/versions", methods=["GET"])
@admin_required
def api_prompt_versions(prompt_key):
    """Get all versions for one prompt key"""
    return jsonify(get_prompt_versions(prompt_key))

@main.route("/admin/api/prompts", methods=["POST"])
@admin_required
def api_create_prompt():
    """Create new prompt (version 1)"""
    admin = get_current_admin()
    data = request.json
    prompt_key = data.get("prompt_key")
    prompt_name = data.get("prompt_name")
    prompt_content = data.get("prompt_content")
    notes = data.get("notes", "")
    if not (prompt_key and prompt_name and prompt_content):
        return jsonify({"error": "Missing fields"}), 400
    new_id = create_prompt(prompt_key, prompt_name, prompt_content, admin["id"], notes)
    if new_id:
        return jsonify({"success": True, "id": new_id})
    return jsonify({"error": "Failed to create prompt"}), 500

@main.route("/admin/api/prompts/<prompt_key>/version", methods=["POST"])
@admin_required
def api_add_prompt_version(prompt_key):
    """Add a new version to a prompt"""
    admin = get_current_admin()
    data = request.json
    prompt_name = data.get("prompt_name")
    prompt_content = data.get("prompt_content")
    notes = data.get("notes", "")
    if not (prompt_name and prompt_content):
        return jsonify({"error": "Missing fields"}), 400
    new_id = add_prompt_version(prompt_key, prompt_name, prompt_content, admin["id"], notes)
    if new_id:
        return jsonify({"success": True, "id": new_id})
    return jsonify({"error": "Failed to add prompt version"}), 500

@main.route("/admin/api/prompts/<int:prompt_id>/activate", methods=["POST"])
@admin_required
def api_activate_prompt(prompt_id):
    """Set a prompt version active"""
    success = update_prompt_active(prompt_id)
    if success:
        return jsonify({"success": True})
    return jsonify({"error": "Failed to activate prompt"}), 500

@main.route("/admin/api/prompts/<int:prompt_id>", methods=["DELETE"])
@admin_required
def api_delete_prompt_version(prompt_id):
    """Delete prompt version"""
    success = delete_prompt_version(prompt_id)
    if success:
        return jsonify({"success": True})
    return jsonify({"error": "Failed to delete prompt"}), 500

@main.route("/admin/api/prompts", methods=["GET"])
@admin_required
def api_prompts_get():
    """
    Return all prompts for admin page as a flat list (for compatibility with frontend JS)
    """
    prompt_dict = get_prompts_all()  # returns {key: [versions...], ...}
    prompts = []
    for key, versions in prompt_dict.items():
        active = next((v for v in versions if v.get("is_active")), None)
        if active:
            prompt_copy = dict(active)
            prompt_copy['active_version'] = active.get('version')
            prompts.append(prompt_copy)
    return jsonify({"prompts": prompts})


# Add these routes to your routes.py file

# ---------------------------------------------------------------------- 
# Admin Activity Log Routes

@main.route("/admin/activity", methods=["GET"])
@admin_required
def admin_activity_page():
    """Admin activity log page"""
    return render_template("admin_activity.html")

@main.route("/admin/api/activities", methods=["GET"])
@admin_required
def api_admin_get_activities():
    """Get admin activity log with pagination and filtering"""
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        search = request.args.get('search', '')
        action_filter = request.args.get('action', 'all')
        date_filter = request.args.get('date_filter', 'all')
        
        offset = (page - 1) * limit
        
        # Build query conditions
        where_conditions = []
        params = []
        
        if search:
            where_conditions.append("(action ILIKE %s OR details::text ILIKE %s)")
            params.extend([f"%{search}%", f"%{search}%"])
            
        if action_filter != 'all':
            where_conditions.append("action = %s")
            params.append(action_filter)
            
        if date_filter != 'all':
            if date_filter == 'today':
                where_conditions.append("created_at >= CURRENT_DATE")
            elif date_filter == 'yesterday':
                where_conditions.append("created_at >= CURRENT_DATE - INTERVAL '1 day' AND created_at < CURRENT_DATE")
            elif date_filter == 'week':
                where_conditions.append("created_at >= CURRENT_DATE - INTERVAL '7 days'")
            elif date_filter == 'month':
                where_conditions.append("created_at >= CURRENT_DATE - INTERVAL '30 days'")
        
        where_clause = "WHERE " + " AND ".join(where_conditions) if where_conditions else ""
        
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            
            # Get total count
            count_query = f"SELECT COUNT(*) FROM admin_activity_log {where_clause}"
            cursor.execute(count_query, params)
            total_count = cursor.fetchone()[0]
            
            # Get activities
            activities_query = f"""
                SELECT id, admin_id, action, target_type, target_id, details, 
                       ip_address, user_agent, created_at
                FROM admin_activity_log 
                {where_clause}
                ORDER BY created_at DESC
                LIMIT %s OFFSET %s
            """
            params.extend([limit, offset])
            cursor.execute(activities_query, params)
            
            activities = []
            for row in cursor.fetchall():
                activities.append({
                    'id': row[0],
                    'admin_id': row[1],
                    'action': row[2],
                    'target_type': row[3],
                    'target_id': row[4],
                    'details': row[5] if isinstance(row[5], dict) else None,
                    'ip_address': row[6],
                    'user_agent': row[7],
                    'created_at': row[8].isoformat() if row[8] else None
                })
            
            return jsonify({
                'activities': activities,
                'total_count': total_count,
                'page': page,
                'limit': limit,
                'total_pages': (total_count + limit - 1) // limit
            })
            
    except Exception as e:
        logger.error(f"Error getting admin activities: {e}")
        return jsonify({"error": "Failed to load activities"}), 500

@main.route("/admin/api/activities/export", methods=["GET"])
@admin_required
def api_admin_export_activities():
    """Export activity log as CSV"""
    try:
        import csv
        import io
        
        search = request.args.get('search', '')
        action_filter = request.args.get('action', 'all')
        date_filter = request.args.get('date_filter', 'all')
        
        # Build query (similar to above)
        where_conditions = []
        params = []
        
        if search:
            where_conditions.append("(action ILIKE %s OR details::text ILIKE %s)")
            params.extend([f"%{search}%", f"%{search}%"])
            
        if action_filter != 'all':
            where_conditions.append("action = %s")
            params.append(action_filter)
            
        if date_filter != 'all':
            if date_filter == 'today':
                where_conditions.append("created_at >= CURRENT_DATE")
            elif date_filter == 'yesterday':
                where_conditions.append("created_at >= CURRENT_DATE - INTERVAL '1 day' AND created_at < CURRENT_DATE")
            elif date_filter == 'week':
                where_conditions.append("created_at >= CURRENT_DATE - INTERVAL '7 days'")
            elif date_filter == 'month':
                where_conditions.append("created_at >= CURRENT_DATE - INTERVAL '30 days'")
        
        where_clause = "WHERE " + " AND ".join(where_conditions) if where_conditions else ""
        
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            query = f"""
                SELECT admin_id, action, target_type, target_id, details, 
                       ip_address, created_at
                FROM admin_activity_log 
                {where_clause}
                ORDER BY created_at DESC
            """
            cursor.execute(query, params)
            
            # Create CSV
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow(['Admin ID', 'Action', 'Target Type', 'Target ID', 'Details', 'IP Address', 'Date'])
            
            for row in cursor.fetchall():
                writer.writerow([
                    row[0],  # admin_id
                    row[1],  # action
                    row[2] or '',  # target_type
                    row[3] or '',  # target_id
                    str(row[4]) if row[4] else '',  # details
                    row[5] or '',  # ip_address
                    row[6].isoformat() if row[6] else ''  # created_at
                ])
            
            csv_data = output.getvalue()
            output.close()
            
            response = make_response(csv_data)
            response.headers["Content-Disposition"] = f"attachment; filename=activity_log_{datetime.now().strftime('%Y%m%d')}.csv"
            response.headers["Content-Type"] = "text/csv"
            return response
            
    except Exception as e:
        logger.error(f"Error exporting activities: {e}")
        return jsonify({"error": "Export failed"}), 500

# ---------------------------------------------------------------------- 
# Admin Settings Routes

@main.route("/admin/settings", methods=["GET"])
@admin_required
def admin_settings_page():
    """Admin settings page"""
    return render_template("admin_settings.html")

@main.route("/admin/api/settings", methods=["GET"])
@admin_required
def api_admin_get_settings():
    """Get all system settings"""
    try:
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT setting_key, setting_value FROM system_settings")
            
            settings = {}
            for row in cursor.fetchall():
                key_parts = row[0].split('.')
                if len(key_parts) == 2:
                    category, setting = key_parts
                    if category not in settings:
                        settings[category] = {}
                    try:
                        # Try to parse as JSON, fallback to string
                        settings[category][setting] = json.loads(row[1])
                    except (json.JSONDecodeError, TypeError):
                        settings[category][setting] = row[1]
            
            return jsonify(settings)
            
    except Exception as e:
        logger.error(f"Error getting settings: {e}")
        # Return default settings if database fails
        return jsonify({
            'general': {
                'system_name': 'FlameGuardAI™',
                'system_version': '2.1.0',
                'max_users': 10000,
                'session_timeout': 24,
                'description': 'AI-powered fire risk assessment platform'
            },
            'email': {
                'smtp_server': '',
                'smtp_port': 587,
                'from_email': '',
                'from_name': 'FlameGuardAI™ System',
                'enable_notifications': True,
                'enable_admin_alerts': True
            },
            'security': {
                'max_login_attempts': 5,
                'lockout_duration': 30,
                'code_expiry': 10,
                'admin_session_timeout': 8,
                'enable_2fa': False,
                'enable_ip_whitelist': False,
                'log_security_events': True
            },
            'api': {
                'rate_limit': 100,
                'max_file_size': 10,
                'vision_timeout': 30,
                'sonar_timeout': 45,
                'enable_logging': True
            },
            'maintenance': {
                'enabled': False
            }
        })

@main.route("/admin/api/settings/<category>", methods=["POST"])
@admin_required
def api_admin_save_settings(category):
    """Save settings for a specific category"""
    try:
        admin = get_current_admin()
        data = request.get_json()
        
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            
            # Save each setting
            for key, value in data.items():
                setting_key = f"{category}.{key}"
                setting_value = json.dumps(value) if not isinstance(value, str) else value
                
                cursor.execute("""
                    INSERT INTO system_settings (setting_key, setting_value, updated_by, updated_at)
                    VALUES (%s, %s, %s, NOW())
                    ON CONFLICT (setting_key) 
                    DO UPDATE SET 
                        setting_value = EXCLUDED.setting_value,
                        updated_by = EXCLUDED.updated_by,
                        updated_at = EXCLUDED.updated_at
                """, (setting_key, setting_value, admin['id']))
            
            # special check when updating max_users
            if category == 'general' and 'max_users' in data:
                new_limit = int(data['max_users'])
                cursor.execute("SELECT COUNT(*) FROM users WHERE is_active = TRUE")
                active_users = cursor.fetchone()[0]
                if new_limit < active_users:
                    conn.rollback()
                    return jsonify({
                        "error": f"Max users must be ≥ current active users ({active_users})."
                    }), 400

            conn.commit()
        
        # Log the settings update
        log_admin_activity(admin['id'], 'settings_updated', 'system', None, {
            'category': category,
            'settings_count': len(data)
        })
        
        return jsonify({"message": f"{category.title()} settings saved successfully"})
        
    except Exception as e:
        logger.error(f"Error saving {category} settings: {e}")
        return jsonify({"error": f"Failed to save {category} settings"}), 500

@main.route("/admin/api/settings/email/test", methods=["POST"])
@admin_required
def api_admin_test_email():
    """Test email configuration"""
    try:
        admin = get_current_admin()
        
        # Get current email settings
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT setting_key, setting_value 
                FROM system_settings 
                WHERE setting_key LIKE 'email.%'
            """)
            
            email_settings = {}
            for row in cursor.fetchall():
                key = row[0].split('.')[1]
                try:
                    email_settings[key] = json.loads(row[1])
                except:
                    email_settings[key] = row[1]
        
        # Send test email using the current settings
        from .admin_email_utils import send_admin_test_email
        success = send_admin_test_email(
            admin['email'], 
            email_settings.get('smtp_server', ''),
            email_settings.get('smtp_port', 587),
            email_settings.get('from_email', ''),
            email_settings.get('from_name', 'FlameGuardAI™ System')
        )
        
        if success:
            return jsonify({"message": "Test email sent successfully"})
        else:
            return jsonify({"error": "Test email failed"}), 500
            
    except Exception as e:
        logger.error(f"Error testing email: {e}")
        return jsonify({"error": "Email test failed"}), 500

@main.route("/admin/api/maintenance/cleanup", methods=["POST"])
@admin_required
def api_admin_cleanup_database():
    """Clean up expired database entries"""
    try:
        admin = get_current_admin()
        
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            
            # Clean expired admin sessions
            cursor.execute("DELETE FROM admin_sessions WHERE expires_at < NOW()")
            admin_sessions_cleaned = cursor.rowcount
            
            # Clean expired admin verification codes
            cursor.execute("DELETE FROM admin_verification_codes WHERE expires_at < NOW()")
            admin_codes_cleaned = cursor.rowcount
            
            conn.commit()
        
        # Clean expired user sessions and codes from main database
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            # Clean expired user sessions
            cursor.execute("DELETE FROM user_sessions WHERE expires_at < NOW()")
            user_sessions_cleaned = cursor.rowcount
            
            # Clean expired verification codes
            cursor.execute("DELETE FROM verification_codes WHERE expires_at < NOW()")
            user_codes_cleaned = cursor.rowcount
            
            conn.commit()
        
        total_cleaned = admin_sessions_cleaned + admin_codes_cleaned + user_sessions_cleaned + user_codes_cleaned
        
        # Log the cleanup
        log_admin_activity(admin['id'], 'database_cleanup', 'system', None, {
            'admin_sessions_cleaned': admin_sessions_cleaned,
            'admin_codes_cleaned': admin_codes_cleaned,
            'user_sessions_cleaned': user_sessions_cleaned,
            'user_codes_cleaned': user_codes_cleaned,
            'total_cleaned': total_cleaned
        })
        
        return jsonify({
            "message": "Database cleanup completed",
            "cleaned_items": total_cleaned
        })
        
    except Exception as e:
        logger.error(f"Error during database cleanup: {e}")
        return jsonify({"error": "Database cleanup failed"}), 500

@main.route("/admin/api/maintenance/cache", methods=["DELETE"])
@admin_required
def api_admin_clear_cache():
    """Clear system cache"""
    try:
        admin = get_current_admin()
        
        # Clear any application cache here
        # This could include Redis cache, file cache, etc.
        # For now, we'll just log the action
        
        log_admin_activity(admin['id'], 'cache_cleared', 'system', None, {
            'cache_type': 'all'
        })
        
        return jsonify({"message": "Cache cleared successfully"})
        
    except Exception as e:
        logger.error(f"Error clearing cache: {e}")
        return jsonify({"error": "Cache clear failed"}), 500

@main.route("/admin/api/export/system-data", methods=["POST"])
@admin_required
def api_admin_export_system_data():
    """Export system data as ZIP file"""
    try:
        import zipfile
        import tempfile
        import csv
        
        admin = get_current_admin()
        
        # Create temporary zip file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.zip') as tmp_file:
            with zipfile.ZipFile(tmp_file.name, 'w', zipfile.ZIP_DEFLATED) as zipf:
                
                # Export admin activity log
                with get_admin_db_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute("""
                        SELECT admin_id, action, target_type, target_id, details, 
                               ip_address, created_at
                        FROM admin_activity_log 
                        ORDER BY created_at DESC
                    """)
                    
                    # Create CSV in memory
                    csv_content = io.StringIO()
                    writer = csv.writer(csv_content)
                    writer.writerow(['Admin ID', 'Action', 'Target Type', 'Target ID', 'Details', 'IP Address', 'Date'])
                    
                    for row in cursor.fetchall():
                        writer.writerow([
                            row[0], row[1], row[2] or '', row[3] or '',
                            str(row[4]) if row[4] else '', row[5] or '',
                            row[6].isoformat() if row[6] else ''
                        ])
                    
                    zipf.writestr('admin_activity_log.csv', csv_content.getvalue())
                    csv_content.close()
                
                # Export system settings
                with get_admin_db_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute("SELECT setting_key, setting_value FROM system_settings")
                    
                    settings_content = io.StringIO()
                    writer = csv.writer(settings_content)
                    writer.writerow(['Setting Key', 'Setting Value'])
                    
                    for row in cursor.fetchall():
                        writer.writerow([row[0], row[1]])
                    
                    zipf.writestr('system_settings.csv', settings_content.getvalue())
                    settings_content.close()
                
                # Export user statistics
                with get_db_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute("""
                        SELECT COUNT(*) as total_users,
                               COUNT(CASE WHEN created_at > NOW() - INTERVAL '30 days' THEN 1 END) as new_users_month,
                               (SELECT COUNT(*) FROM assessments) as total_assessments
                        FROM users
                    """)
                    
                    stats = cursor.fetchone()
                    stats_content = f"""System Statistics Export
Generated: {datetime.now().isoformat()}
Generated by: Admin ID {admin['id']}

Total Users: {stats[0]}
New Users (Last 30 Days): {stats[1]}
Total Assessments: {stats[2]}
"""
                    zipf.writestr('system_statistics.txt', stats_content)
            
            # Read the zip file and return as response
            with open(tmp_file.name, 'rb') as f:
                zip_data = f.read()
            
            # Clean up temp file
            os.unlink(tmp_file.name)
            
            # Log the export
            log_admin_activity(admin['id'], 'data_exported', 'system', None, {
                'export_type': 'full_system_data'
            })
            
            response = make_response(zip_data)
            response.headers["Content-Disposition"] = f"attachment; filename=system_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
            response.headers["Content-Type"] = "application/zip"
            return response
            
    except Exception as e:
        logger.error(f"Error exporting system data: {e}")
        return jsonify({"error": "Data export failed"}), 500

@main.route("/admin/api/settings/reset", methods=["POST"])
@admin_required
def api_admin_reset_settings():
    """Reset all system settings to defaults"""
    try:
        admin = get_current_admin()
        
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            
            # Delete all current settings
            cursor.execute("DELETE FROM system_settings")
            
            # Insert default settings
            default_settings = [
                ('general.system_name', 'FlameGuardAI™'),
                ('general.system_version', '2.1.0'),
                ('general.max_users', '10000'),
                ('general.session_timeout', '24'),
                ('general.description', 'AI-powered fire risk assessment platform'),
                ('email.smtp_port', '587'),
                ('email.from_name', 'FlameGuardAI™ System'),
                ('email.enable_notifications', 'true'),
                ('email.enable_admin_alerts', 'true'),
                ('security.max_login_attempts', '5'),
                ('security.lockout_duration', '30'),
                ('security.code_expiry', '10'),
                ('security.admin_session_timeout', '8'),
                ('security.enable_2fa', 'false'),
                ('security.enable_ip_whitelist', 'false'),
                ('security.log_security_events', 'true'),
                ('api.rate_limit', '100'),
                ('api.max_file_size', '10'),
                ('api.vision_timeout', '30'),
                ('api.sonar_timeout', '45'),
                ('api.enable_logging', 'true'),
                ('maintenance.enabled', 'false')
            ]
            
            for setting_key, setting_value in default_settings:
                cursor.execute("""
                    INSERT INTO system_settings (setting_key, setting_value, updated_by, updated_at)
                    VALUES (%s, %s, %s, NOW())
                """, (setting_key, setting_value, admin['id']))
            
            conn.commit()
        
        # Log the reset
        log_admin_activity(admin['id'], 'settings_reset', 'system', None, {
            'reset_type': 'all_settings'
        })
        
        return jsonify({"message": "System settings reset to defaults"})
        
    except Exception as e:
        logger.error(f"Error resetting settings: {e}")
        return jsonify({"error": "Settings reset failed"}), 500

@main.route("/admin/api/settings/maintenance", methods=["POST"])
@admin_required
def api_admin_toggle_maintenance():
    """Toggle maintenance mode"""
    try:
        admin = get_current_admin()
        data = request.get_json()
        enabled = data.get('enabled', False)
        
        with get_admin_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO system_settings (setting_key, setting_value, updated_by, updated_at)
                VALUES ('maintenance.enabled', %s, %s, NOW())
                ON CONFLICT (setting_key) 
                DO UPDATE SET 
                    setting_value = EXCLUDED.setting_value,
                    updated_by = EXCLUDED.updated_by,
                    updated_at = EXCLUDED.updated_at
            """, (json.dumps(enabled), admin['id']))
            
            conn.commit()
        
        # Log the maintenance mode change
        log_admin_activity(admin['id'], 'maintenance_mode_toggled', 'system', None, {
            'enabled': enabled
        })
        
        return jsonify({"message": f"Maintenance mode {'enabled' if enabled else 'disabled'}"})
        
    except Exception as e:
        logger.error(f"Error toggling maintenance mode: {e}")
        return jsonify({"error": "Failed to toggle maintenance mode"}), 500

import os
from flask import send_file, abort, current_app
from werkzeug.utils import secure_filename

@main.route('/api/image/<filename>')
@login_required
def serve_image(filename):
    """
    Serve images from the uploads directory configured in .env
    """
    try:
        # Secure the filename to prevent directory traversal attacks
        safe_filename = secure_filename(filename)
        
        # Get the upload folder from Flask config (same as used in save_image)
        upload_folder = current_app.config['UPLOAD_FOLDER']
        
        # Full path to the image
        image_path = os.path.join(upload_folder, safe_filename)
        
        # Check if file exists
        if not os.path.exists(image_path):
            abort(404)
        
        # Check if it's actually a file (not a directory)
        if not os.path.isfile(image_path):
            abort(404)
            
        # Validate file extension (optional security measure)
        allowed_extensions = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}
        file_ext = os.path.splitext(safe_filename)[1].lower()
        if file_ext not in allowed_extensions:
            abort(404)
        
        # Serve the file
        return send_file(image_path, as_attachment=False)
        
    except Exception as e:
        print(f"Error serving image {filename}: {e}")
        abort(404)


# Add these routes to your existing routes.py file
# These are MCP-specific API endpoints that work with session tokens instead of cookies
from .db_setup import get_db_connection

# Add these TWO routes to your existing routes.py file
# These are the missing MCP authentication endpoints that are causing 404 errors

import secrets
from datetime import datetime, timedelta

# In-memory storage for auth codes and sessions (use Redis in production)
# Add these at the top of your routes file
mcp_auth_codes = {}  # email -> {code, expires_at, attempts}
mcp_sessions = {}    # session_token -> {email, user_id, created_at}

import uuid
from .background_jobs import queue_fire_risk_analysis, get_job_status

@main.route("/api/mcp/request-code", methods=["POST"])
def api_mcp_request_code():
    """
    Request authentication code for MCP access
    This is a NEW endpoint that doesn't affect existing functionality
    """
    try:
        data = request.get_json()
        if not data or 'email' not in data:
            return jsonify({
                "success": False,
                "error": "Email is required"
            }), 400
        
        email = data['email'].lower().strip()
        
        # Basic email validation
        if '@' not in email or '.' not in email.split('@')[1]:
            return jsonify({
                "success": False,
                "error": "Invalid email format"
            }), 400
        
        user = get_user_by_email(email)
        if not user or not user['is_active']:
            return jsonify({
                "success": False,
                "error": "Email not registered or not verified. Please sign up first."
            }), 403
        
        # Generate and send verification code (using existing system)
        code = generate_verification_code()
        if store_verification_code(email, code, 'mcp_login'):
            if not send_verification_email(email, code, 'login'):
                return jsonify({
                    "success": False,
                    "error": "Failed to send verification email"
                }), 500
        else:
            return jsonify({
                "success": False,
                "error": "Failed to generate verification code"
            }), 500
        
        # For now, just log the code (you can implement email sending later)
        logger.info(f"MCP Authentication code for {email}: {code}")
        
        # TODO: Send actual email here
        # You can add email sending later without affecting the MCP functionality
        
        return jsonify({
            "success": True,
            "message": "Authentication code sent to email"
        })
        
    except Exception as e:
        logger.error(f"Error in MCP request code: {e}")
        return jsonify({
            "success": False,
            "error": "Internal server error"
        }), 500

@main.route("/api/mcp/verify-code", methods=["POST"])
def api_mcp_verify_code():
    """
    Verify authentication code and create MCP session
    This is a NEW endpoint that doesn't affect existing functionality
    """
    try:
        data = request.get_json()
        if not data or 'email' not in data or 'code' not in data:
            return jsonify({
                "success": False,
                "error": "Email and code are required"
            }), 400
        
        email = data['email'].lower().strip()
        code = data['code'].strip()
        
        # Verify code using existing system
        if not verify_code(email, code, 'mcp_login'):
            return jsonify({
                "success": False,
                "error": "Invalid or expired verification code"
            }), 400

        # Get user using existing system
        user = get_user_by_email(email)
        if not user or not user['is_active']:
            return jsonify({
                "success": False,
                "error": "User account not found or inactive"
            }), 400

        user_id = user['id']
        
        # Create session token using existing system
        session_token = create_session_token(user_id)
        
        logger.info(f"MCP session created for user {email} with token {session_token[:10]}...")
        
        return jsonify({
            "success": True,
            "session_token": session_token,
            "user_id": user_id,
            "message": "Authentication successful"
        })
        
    except Exception as e:
        logger.error(f"Error in MCP verify code: {e}")
        return jsonify({
            "success": False,
            "error": "Internal server error"
        }), 500


# Helper function to verify MCP session tokens (add this too)
def verify_session_token(session_token):
    """
    Verify MCP session token and return user_id if valid
    This replaces the @login_required decorator for MCP endpoints
    """
    if not session_token or session_token not in mcp_sessions:
        return None
    
    session_data = mcp_sessions[session_token]
    
    # Check if session expired (24 hours)
    if datetime.now() > session_data['created_at'] + timedelta(hours=24):
        del mcp_sessions[session_token]
        return None
    
    return session_data['user_id']

@main.route("/api/mcp/validate-session", methods=["POST"])
def api_mcp_validate_session():
    """
    Validate session token for MCP server (bypasses @login_required)
    """
    try:
        data = request.get_json()
        session_token = data.get('session_token', '')
        
        if not session_token:
            return jsonify({'valid': False, 'error': 'Session token required'}), 400
        
        # DEBUG: Log the token being validated
        logger.info(f"MCP validating token: {session_token[:20]}...")
        
        # Use the auth system's verify_session_token function explicitly
        from .auth import verify_session_token as auth_verify_session_token
        user_id = auth_verify_session_token(session_token)
        
        # DEBUG: Log the result
        logger.info(f"Token validation result: user_id={user_id}")
        
        if user_id:
            # Get user details using existing system
            user = get_user_by_email_from_id(user_id)
            logger.info(f"User lookup result: {user}")
            
            if user and user['is_active']:
                return jsonify({
                    'valid': True,
                    'user_id': user['id'],
                    'email': user['email']
                })
        
        return jsonify({'valid': False, 'error': 'Invalid or expired session'}), 401
        
    except Exception as e:
        logger.error(f"Error validating MCP session: {e}")
        return jsonify({'valid': False, 'error': 'Session validation failed'}), 500

# Replace your existing /api/mcp/analyze and /api/mcp/report routes with these

@main.route("/api/mcp/analyze", methods=["POST"])
def api_mcp_analyze():
    """
    MCP version of analyze endpoint - creates assessment and immediately starts processing
    Returns assessment_id for tracking, but processing continues in background
    """
    try:
        # Get session token from request
        session_token = request.form.get('session_token') or request.headers.get('X-Session-Token')
        
        if not session_token:
            return jsonify({'error': 'Session token required'}), 401
        
        # Validate session token (replaces @login_required)
        from .auth import verify_session_token as auth_verify_session_token
        user_id = auth_verify_session_token(session_token)
        if not user_id:
            return jsonify({'error': 'Invalid or expired session'}), 401
        
        # Get user details
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, email, is_active FROM users WHERE id = %s",
                (user_id,)
            )
            result = cursor.fetchone()
            if not result or not result[2]:  # not active
                return jsonify({'error': 'User account not active'}), 401
        
        user = {'id': result[0], 'email': result[1], 'is_active': result[2]}
        
        # Get analysis parameters
        image_analysis = request.form.get('image_analysis', '')
        zip_code = request.form.get("zip_code", "")
        state = request.form.get("state", "CA")
        image_path = request.form.get('image_path', 'mcp_generated.txt')
        
        if not image_analysis:
            return jsonify({'error': 'Image analysis is required'}), 400
        
        if not zip_code:
            return jsonify({'error': 'ZIP code is required'}), 400
        
        # Create mock analysis result for immediate database storage
        analysis = {
            "summary": f"Fire Risk Analysis for {zip_code}, {state}",
            "detail_response": image_analysis
        }

        # Check if generation is enabled globally
        if not is_generation_enabled():
            return jsonify({
                "error": "Assessment generation is temporarily disabled.",
                "error_type": "generation_disabled"
            }), 503

        # Check if user has credits
        has_credits, message = check_credits_available(user['id'])
        if not has_credits:
            return jsonify({
                "error": message,
                "error_type": "insufficient_credits"
            }), 403
        
        # Save initial assessment to database
        assessment_id = save_assessment(
            user_id=user['id'],
            image_path=image_path,
            zip_code=zip_code,
            state=state,
            user_context="MCP Generated Assessment",
            vision_summary=analysis.get("summary", ""),
            vision_detail=analysis.get("detail_response", "")
        )
        
        logger.info(f"MCP Assessment {assessment_id} created for user {user['email']}")
        
        # Return immediately - processing will continue in background via /api/mcp/report
        return jsonify({
            "assessment_id": assessment_id,
            "summary": analysis.get("summary", ""),
            "detail": analysis.get("detail_response", ""),
            "message": "Assessment created successfully"
        })
        
    except Exception as exc:
        logger.exception("Error during MCP image analysis")
        return jsonify({
            "summary": "Image analysis failed.",
            "detail": str(exc),
        }), 500

import uuid
from .background_jobs import queue_fire_risk_analysis, get_job_status

@main.route("/api/mcp/report", methods=["POST"])
def api_mcp_report():
    """
    MCP version of report endpoint - Queue job for background processing
    Returns immediately with job ID, processing happens in background
    """
    try:
        # Get session token from request
        data = request.get_json()
        session_token = data.get('session_token') or request.headers.get('X-Session-Token')
        
        if not session_token:
            return jsonify({'error': 'Session token required'}), 401
        
        # Validate session token (replaces @login_required)
        from .auth import verify_session_token as auth_verify_session_token
        user_id = auth_verify_session_token(session_token)
        if not user_id:
            return jsonify({'error': 'Invalid or expired session'}), 401
        
        # Get user details
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, email, is_active FROM users WHERE id = %s",
                (user_id,)
            )
            result = cursor.fetchone()
            if not result or not result[2]:  # not active
                return jsonify({'error': 'User account not active'}), 401
        
        user = {'id': result[0], 'email': result[1], 'is_active': result[2]}
        
        # Get report parameters
        assessment_id = data.get("assessment_id")
        detail = data.get("detail", "")
        user_ctx = data.get("context", "")
        zip_code = data.get("zip", "")
        state = data.get("state", "CA")
        use_deep_research = data.get("deep_research", False)
        
        if not assessment_id:
            return jsonify({'error': 'Assessment ID is required'}), 400
        
        # Generate unique job ID
        job_id = f"fire_risk_{assessment_id}_{uuid.uuid4().hex[:8]}"
        
        logger.info(f"Queuing MCP fire risk analysis job {job_id} for assessment {assessment_id}")
        
        # Queue the background job
        queued_job_id = queue_fire_risk_analysis(
            job_id=job_id,
            user_id=user['id'],
            user_email=user['email'],
            assessment_id=assessment_id,
            detail=detail,
            user_context=user_ctx,
            zip_code=zip_code,
            state=state,
            use_deep_research=use_deep_research
        )
        
        # Return immediate response
        return jsonify({
            "success": True,
            "job_id": queued_job_id,
            "assessment_id": assessment_id,
            "status": "queued",
            "message": "Your fire risk analysis has been queued for processing. You will receive a detailed report via email when the analysis is complete.",
            "estimated_time": "5-10 minutes" if use_deep_research else "2-5 minutes",
            "notification_email": user['email']
        })
        
    except Exception as exc:
        logger.exception(f"Error queuing MCP report generation")
        return jsonify({
            "success": False,
            "message": "Failed to queue fire risk analysis.",
            "error": str(exc),
        }), 500


@main.route("/api/mcp/job-status/<job_id>", methods=["GET"])
def api_mcp_job_status(job_id):
    """
    Check the status of a background job (optional endpoint for polling)
    """
    try:
        # Get session token for authentication
        session_token = request.headers.get('X-Session-Token') or request.args.get('session_token')
        
        if not session_token:
            return jsonify({'error': 'Session token required'}), 401
        
        # Validate session token
        user_id = verify_session_token(session_token)
        if not user_id:
            return jsonify({'error': 'Invalid or expired session'}), 401
        
        # Get job status
        status = get_job_status(job_id)
        
        return jsonify({
            "job_id": job_id,
            "status": status.get("status", "not_found"),
            "message": status.get("message", ""),
            "queue_position": status.get("queue_position"),
            "started_at": status.get("started_at"),
            "completed_at": status.get("completed_at"),
            "failed_at": status.get("failed_at"),
            "error": status.get("error")
        })
        
    except Exception as e:
        logger.error(f"Error checking job status for {job_id}: {e}")
        return jsonify({
            "job_id": job_id,
            "status": "error",
            "message": "Failed to check job status"
        }), 500