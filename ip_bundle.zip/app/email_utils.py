"""
Email utilities for FlameGuardAI™ Research Preview
"""
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import logging

logger = logging.getLogger(__name__)

# Email configuration
SMTP_CONFIG = {
    'host': os.getenv('SMTP_HOST', 'smtp.porkbun.com'),
    'port': int(os.getenv('SMTP_PORT', '587')),
    'user': os.getenv('SMTP_USER', 'info@dlyog.com'),
    'password': os.getenv('SMTP_PASSWORD', '')
}

def send_verification_email(email: str, code: str, purpose: str) -> bool:
    """Send verification email to user"""
    try:
        # Create message
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"FlameGuardAI™ Research Preview - {'Login' if purpose == 'login' else 'Account Verification'}"
        msg['From'] = SMTP_CONFIG['user']
        msg['To'] = email

        # Email content based on purpose
        if purpose == 'mcp_auth':
            msg['Subject'] = f"FlameGuardAI™ Research Preview - MCP Authentication Code - {'Login' if purpose == 'login' else 'Account Verification'}" 
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>MCP Authentication Code</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; margin: 0; padding: 20px; background-color: #f4f4f4;">
                <div style="max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
                    <div style="text-align: center; margin-bottom: 30px;">
                        <h1 style="color: #FF8A50; margin: 0;">🔥 FlameGuardAI™</h1>
                        <p style="color: #666; margin: 5px 0;">AI Fire Risk Research Platform</p>
                    </div>
                    
                    <div style="background-color: #FFF5F2; border-left: 4px solid #FF8A50; padding: 20px; margin: 20px 0;">
                        <h2 style="color: #333; margin-top: 0;">MCP Authentication Code</h2>
                        <p style="color: #666; margin-bottom: 15px;">
                            You requested access to FlameGuardAI tools through Claude Desktop or another MCP client.
                        </p>
                        <div style="text-align: center; margin: 25px 0;">
                            <div style="display: inline-block; background-color: #FF8A50; color: white; padding: 15px 30px; border-radius: 8px; font-size: 24px; font-weight: bold; letter-spacing: 3px;">
                                {code}
                            </div>
                        </div>
                        <p style="color: #666; font-size: 14px; margin-bottom: 0;">
                            ⏰ <strong>This code expires in 10 minutes</strong>
                        </p>
                    </div>
                    
                    <div style="background-color: #E8F4FD; border-radius: 8px; padding: 20px; margin: 20px 0;">
                        <h3 style="color: #1976D2; margin-top: 0;">How to use this code:</h3>
                        <ol style="color: #666; margin: 0; padding-left: 20px;">
                            <li>Return to Claude Desktop (or your MCP client)</li>
                            <li>Tell Claude: "Please authenticate me with email {email} and code {code}"</li>
                            <li>Once authenticated, you can use FlameGuardAI fire risk research tools</li>
                        </ol>
                    </div>
                    
                    <div style="background-color: #FFF3CD; border-radius: 8px; padding: 15px; margin: 20px 0;">
                        <p style="color: #856404; margin: 0; font-size: 14px;">
                            <strong>Security Note:</strong> This code is only for MCP authentication and allows access to fire risk research tools. 
                            If you didn't request this code, you can safely ignore this email.
                        </p>
                    </div>
                    
                    <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee;">
                        <p style="color: #999; font-size: 12px; margin: 0;">
                            FlameGuardAI™ - AI for Good Initiative<br>
                            Educational fire risk research platform
                        </p>
                    </div>
                </div>
            </body>
            </html>
            """
            
        elif purpose == 'signup':
            subject_line = "Welcome to FlameGuardAI™ Research Preview!"
            greeting = "Welcome to FlameGuardAI™ Research Preview!"
            message = "Thank you for joining our AI research preview. This is an educational tool that may contain AI inaccuracies. Use the verification code below to activate your account:"
            next_steps = "Once verified, you'll be able to upload property images and receive AI-generated research insights. Remember: this is a research preview for educational purposes only - always consult qualified professionals."
        else:  # login
            subject_line = "Your FlameGuardAI™ Research Preview Login Code"
            greeting = "Welcome back to our research preview!"
            message = "Use the verification code below to securely access your FlameGuardAI™ research preview account:"
            next_steps = "This code will expire in 10 minutes for your security. Remember: this is an educational research tool only."

        # HTML email template
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>{subject_line}</title>
        </head>
        <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #FFF5F2;">
            <div style="max-width: 600px; margin: 0 auto; background-color: white; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
                
                <!-- Header -->
                <div style="background: linear-gradient(135deg, #FF8A50 0%, #E67347 100%); padding: 40px 30px; text-align: center;">
                    <div style="background-color: white; width: 60px; height: 60px; border-radius: 15px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 20px;">
                        <span style="font-size: 28px;">🧪</span>
                    </div>
                    <h1 style="color: white; margin: 0; font-size: 28px; font-weight: bold;">FlameGuardAI™</h1>
                    <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0 0; font-size: 16px;">AI Research Preview - Educational Use Only</p>
                </div>
                
                <!-- Content -->
                <div style="padding: 40px 30px;">
                    <h2 style="color: #333; margin: 0 0 20px 0; font-size: 24px;">{greeting}</h2>
                    <p style="color: #666; line-height: 1.6; margin: 0 0 30px 0; font-size: 16px;">{message}</p>
                    
                    <!-- Verification Code -->
                    <div style="background: linear-gradient(135deg, #FFE8E0 0%, #FFF5F2 100%); border: 2px solid #FF8A50; border-radius: 15px; padding: 30px; text-align: center; margin: 30px 0;">
                        <p style="color: #666; margin: 0 0 10px 0; font-size: 14px; font-weight: 600;">Your Verification Code</p>
                        <div style="font-size: 36px; font-weight: bold; color: #FF8A50; letter-spacing: 8px; font-family: monospace;">{code}</div>
                    </div>
                    
                    <p style="color: #666; line-height: 1.6; margin: 30px 0 0 0; font-size: 16px;">{next_steps}</p>
                    
                    <!-- Research Preview Notice -->
                    <div style="background-color: #FEF3C7; border: 2px solid #D97706; border-radius: 12px; padding: 20px; margin: 25px 0;">
                        <div style="display: flex; align-items: start;">
                            <span style="font-size: 20px; margin-right: 10px;">🧪</span>
                            <div>
                                <h4 style="color: #92400E; margin: 0 0 8px 0; font-size: 16px;">Research Preview Tool</h4>
                                <p style="color: #92400E; margin: 0; font-size: 14px; line-height: 1.4;">
                                    FlameGuardAI™ is an experimental research tool developed for educational purposes. 
                                    AI analysis may contain inaccuracies. Always consult qualified local professionals for actual fire safety advice.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Security Notice -->
                    <div style="background-color: #F8F9FA; border-left: 4px solid #FF8A50; padding: 20px; margin: 30px 0; border-radius: 0 10px 10px 0;">
                        <p style="margin: 0; color: #666; font-size: 14px;">
                            <strong style="color: #FF8A50;">🔒 Security & Research Notice:</strong> This code expires in 10 minutes. FlameGuardAI™ is a research preview tool - AI analysis may be inaccurate. Always consult local fire experts for professional advice.
                        </p>
                    </div>
                </div>
                
                <!-- Footer -->
                <div style="background-color: #2D3748; padding: 30px; text-align: center;">
                    <p style="color: #A0AEC0; margin: 0; font-size: 14px;">
                        © 2025 FlameGuardAI™ Research Preview. Educational AI tool - no professional claims made.
                    </p>
                    <p style="color: #A0AEC0; margin: 10px 0 0 0; font-size: 12px;">
                        This email was sent to {email}. Research Preview - for educational purposes only.
                    </p>
                </div>
            </div>
        </body>
        </html>
        """

        # Plain text version
        text_content = f"""
        {greeting}
        
        {message}
        
        Your verification code: {code}
        
        {next_steps}
        
        ⚠️ RESEARCH PREVIEW NOTICE: FlameGuardAI™ is an experimental research tool for educational purposes. AI analysis may be inaccurate. Always consult qualified local professionals for actual fire safety advice.
        
        Security Notice: This code expires in 10 minutes. If you didn't request this code, please ignore this email.
        
        ---
        FlameGuardAI™ Research Preview
        Educational AI tool - no professional claims made
        
        This email was sent to {email}
        """

        # Create message parts
        text_part = MIMEText(text_content, 'plain')
        html_part = MIMEText(html_content, 'html')
        
        msg.attach(text_part)
        msg.attach(html_part)

        # Send email
        with smtplib.SMTP(SMTP_CONFIG['host'], SMTP_CONFIG['port']) as server:
            server.starttls()
            server.login(SMTP_CONFIG['user'], SMTP_CONFIG['password'])
            server.send_message(msg)
        
        logger.info(f"Verification email sent to {email} for {purpose}")
        return True
        
    except Exception as e:
        logger.error(f"Error sending email to {email}: {e}")
        return False

def send_welcome_email(email: str, user_name: str = None) -> bool:
    """Send welcome email after successful signup"""
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = "Welcome to FlameGuardAI™ Research Preview - Educational AI Tool"
        msg['From'] = SMTP_CONFIG['user']
        msg['To'] = email

        name = user_name or "Research Participant"
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Welcome to FlameGuardAI™ Research Preview</title>
        </head>
        <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #FFF5F2;">
            <div style="max-width: 600px; margin: 0 auto; background-color: white; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
                
                <!-- Header -->
                <div style="background: linear-gradient(135deg, #FF8A50 0%, #E67347 100%); padding: 40px 30px; text-align: center;">
                    <div style="background-color: white; width: 60px; height: 60px; border-radius: 15px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 20px;">
                        <span style="font-size: 28px;">🧪</span>
                    </div>
                    <h1 style="color: white; margin: 0; font-size: 28px; font-weight: bold;">Welcome to FlameGuardAI™ Research Preview!</h1>
                    <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0 0; font-size: 16px;">Your AI research experience begins - educational use only</p>
                </div>
                
                <!-- Content -->
                <div style="padding: 40px 30px;">
                    <h2 style="color: #333; margin: 0 0 20px 0; font-size: 24px;">Hi {name}! 👋</h2>
                    <p style="color: #666; line-height: 1.6; margin: 0 0 20px 0; font-size: 16px;">
                        Welcome to our AI research preview! You're now part of a community exploring fire risk education through AI technology. 
                        Remember: this is a research tool that may contain inaccuracies - always consult qualified professionals for actual fire safety decisions.
                    </p>
                    
                    <!-- Research Preview Warning -->
                    <div style="background-color: #FEF3C7; border: 2px solid #D97706; border-radius: 12px; padding: 20px; margin: 25px 0;">
                        <div style="display: flex; align-items: start;">
                            <span style="font-size: 20px; margin-right: 10px;">⚠️</span>
                            <div>
                                <h4 style="color: #92400E; margin: 0 0 8px 0; font-size: 16px;">Research Preview Reminder</h4>
                                <p style="color: #92400E; margin: 0; font-size: 14px; line-height: 1.4;">
                                    All AI analysis is for educational purposes and may be inaccurate. Always verify with qualified local professionals.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <h3 style="color: #FF8A50; margin: 30px 0 15px 0; font-size: 20px;">🚀 Ready to explore our research tool?</h3>
                    <div style="background: linear-gradient(135deg, #FFE8E0 0%, #FFF5F2 100%); border-radius: 15px; padding: 25px; margin: 20px 0;">
                        <ol style="margin: 0; padding-left: 20px; color: #666; line-height: 1.8;">
                            <li><strong>Upload property images</strong> - For AI research analysis (educational purposes)</li>
                            <li><strong>Get AI insights</strong> - Research-based analysis that may contain inaccuracies</li>
                            <li><strong>Review research findings</strong> - Educational insights only, not professional advice</li>
                            <li><strong>Consult real experts</strong> - Always verify with qualified local professionals</li>
                        </ol>
                    </div>
                    
                    <h3 style="color: #FF8A50; margin: 30px 0 15px 0; font-size: 20px;">💡 Research Preview Guidelines:</h3>
                    <ul style="color: #666; line-height: 1.8; margin: 0; padding-left: 20px;">
                        <li>Take photos during daylight hours for better AI analysis</li>
                        <li>Capture multiple angles of your home's exterior</li>
                        <li>Include roof, siding, decks, and surrounding vegetation</li>
                        <li>Remember: AI insights are experimental and may be incorrect</li>
                        <li>Always consult local fire departments and contractors for real advice</li>
                    </ul>
                    
                    <div style="text-align: center; margin: 40px 0;">
                        <a href="https://fireguardpro.com/assessment" style="background: linear-gradient(135deg, #FF8A50 0%, #E67347 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 10px; font-weight: bold; display: inline-block;">
                            Start Research Preview 🧪
                        </a>
                    </div>
                </div>
                
                <!-- Footer -->
                <div style="background-color: #2D3748; padding: 30px; text-align: center;">
                    <p style="color: #A0AEC0; margin: 0; font-size: 14px;">
                        © 2025 FlameGuardAI™ Research Preview. Educational AI tool developed for Perplexity Hackathon.
                    </p>
                    <p style="color: #A0AEC0; margin: 10px 0 0 0; font-size: 12px;">
                        Questions? Remember this is a research preview - consult local experts for professional advice.
                    </p>
                </div>
            </div>
        </body>
        </html>
        """

        text_content = f"""
        Welcome to FlameGuardAI™ Research Preview, {name}!
        
        Welcome to our AI research preview! You're now part of a community exploring fire risk education through AI technology. 
        Remember: this is a research tool that may contain inaccuracies - always consult qualified professionals for actual fire safety decisions.
        
        ⚠️ RESEARCH PREVIEW NOTICE: All AI analysis is for educational purposes and may be inaccurate. Always verify with qualified local professionals.
        
        Ready to explore our research tool?
        1. Upload property images - For AI research analysis (educational purposes)
        2. Get AI insights - Research-based analysis that may contain inaccuracies
        3. Review research findings - Educational insights only, not professional advice
        4. Consult real experts - Always verify with qualified local professionals
        
        Research Preview Guidelines:
        • Take photos during daylight hours for better AI analysis
        • Capture multiple angles of your home's exterior
        • Include roof, siding, decks, and surrounding vegetation
        • Remember: AI insights are experimental and may be incorrect
        • Always consult local fire departments and contractors for real advice
        
        Start your research preview at: https://fireguardpro.com/assessment
        
        ---
        FlameGuardAI™ Research Preview Team
        Educational AI tool developed for Perplexity Hackathon
        
        Questions? Remember this is a research preview - consult local experts for professional advice.
        """

        text_part = MIMEText(text_content, 'plain')
        html_part = MIMEText(html_content, 'html')
        
        msg.attach(text_part)
        msg.attach(html_part)

        with smtplib.SMTP(SMTP_CONFIG['host'], SMTP_CONFIG['port']) as server:
            server.starttls()
            server.login(SMTP_CONFIG['user'], SMTP_CONFIG['password'])
            server.send_message(msg)
        
        logger.info(f"Welcome email sent to {email}")
        return True
        
    except Exception as e:
        logger.error(f"Error sending welcome email to {email}: {e}")
        return False

def send_generic_email(email: str, subject: str, html_content: str, text_content: str = None) -> bool:
    """Send a generic email to any recipient (HTML and plain text)."""
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f"FlameGuardAI™ Research Preview - {subject}"
        msg['From'] = SMTP_CONFIG['user']
        msg['To'] = email

        # Add research preview disclaimer to generic emails
        enhanced_html_content = f"""
        {html_content}
        
        <!-- Research Preview Disclaimer -->
        <div style="background-color: #FEF3C7; border: 2px solid #D97706; border-radius: 12px; padding: 20px; margin: 25px 0;">
            <div style="display: flex; align-items: start;">
                <span style="font-size: 20px; margin-right: 10px;">🧪</span>
                <div>
                    <h4 style="color: #92400E; margin: 0 0 8px 0; font-size: 16px;">Research Preview Tool</h4>
                    <p style="color: #92400E; margin: 0; font-size: 14px; line-height: 1.4;">
                        FlameGuardAI™ is an experimental research tool developed for educational purposes. 
                        AI analysis may contain inaccuracies. Always consult qualified local professionals for actual fire safety advice.
                    </p>
                </div>
            </div>
        </div>
        """

        enhanced_text_content = f"""
        {text_content or subject}
        
        ⚠️ RESEARCH PREVIEW NOTICE: FlameGuardAI™ is an experimental research tool for educational purposes. AI analysis may be inaccurate. Always consult qualified local professionals for actual fire safety advice.
        """

        # Attach plain text part if provided, else fallback to subject.
        text_part = MIMEText(enhanced_text_content, 'plain')
        html_part = MIMEText(enhanced_html_content, 'html')

        msg.attach(text_part)
        msg.attach(html_part)

        with smtplib.SMTP(SMTP_CONFIG['host'], SMTP_CONFIG['port']) as server:
            server.starttls()
            server.login(SMTP_CONFIG['user'], SMTP_CONFIG['password'])
            server.send_message(msg)

        logger.info(f"Generic email sent to {email} (subject: {subject})")
        return True
    except Exception as e:
        logger.error(f"Error sending generic email to {email}: {e}")
        return False

def send_assessment_complete_email(email: str, user_name: str, assessment_id: int, risk_rating: str, summary: str) -> bool:
    """Send email notification when comprehensive assessment is complete"""
    try:
        base_url = os.getenv('BASE_URL', 'http://127.0.0.1:5000')
        assessment_url = f"{base_url}/assessment/{assessment_id}"
        
        msg = MIMEMultipart('alternative')
        msg['Subject'] = "🧪 Your AI Research Analysis is Ready - Educational Use Only"
        msg['From'] = SMTP_CONFIG['user']
        msg['To'] = email

        name = user_name or "Research Participant"
        
        # Risk rating colors and emojis
        risk_colors = {
            'High': {'color': '#DC2626', 'bg': '#FEE2E2', 'emoji': '🚨'},
            'Medium': {'color': '#D97706', 'bg': '#FEF3C7', 'emoji': '⚠️'},
            'Low': {'color': '#059669', 'bg': '#D1FAE5', 'emoji': '✅'},
        }
        risk_style = risk_colors.get(risk_rating, risk_colors['Medium'])
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Your AI Research Analysis is Ready</title>
        </head>
        <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #FFF5F2;">
            <div style="max-width: 600px; margin: 0 auto; background-color: white; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
                
                <!-- Header -->
                <div style="background: linear-gradient(135deg, #FF8A50 0%, #E67347 100%); padding: 40px 30px; text-align: center;">
                    <div style="background-color: white; width: 60px; height: 60px; border-radius: 15px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 20px;">
                        <span style="font-size: 28px;">🧪</span>
                    </div>
                    <h1 style="color: white; margin: 0; font-size: 28px; font-weight: bold;">Research Analysis Complete!</h1>
                    <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0 0; font-size: 16px;">Your AI research analysis is ready - educational use only</p>
                </div>
                
                <!-- Content -->
                <div style="padding: 40px 30px;">
                    <h2 style="color: #333; margin: 0 0 20px 0; font-size: 24px;">Hi {name}! 👋</h2>
                    <p style="color: #666; line-height: 1.6; margin: 0 0 30px 0; font-size: 16px;">
                        Your AI research preview analysis is complete! Our experimental AI tool has generated educational insights about your property. 
                        Important: This is a research preview that may contain inaccuracies - always consult qualified local professionals for actual fire safety decisions.
                    </p>
                    
                    <!-- Research Preview Warning -->
                    <div style="background-color: #FEF3C7; border: 2px solid #D97706; border-radius: 12px; padding: 20px; margin: 25px 0;">
                        <div style="display: flex; align-items: start;">
                            <span style="font-size: 20px; margin-right: 10px;">⚠️</span>
                            <div>
                                <h4 style="color: #92400E; margin: 0 0 8px 0; font-size: 16px;">Critical Research Preview Notice</h4>
                                <p style="color: #92400E; margin: 0; font-size: 14px; line-height: 1.4;">
                                    This AI analysis is experimental and may be inaccurate. Do not make fire safety decisions based solely on this research preview. 
                                    Always consult qualified local fire departments, contractors, and inspectors.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Risk Rating -->
                    <div style="background: {risk_style['bg']}; border: 2px solid {risk_style['color']}; border-radius: 15px; padding: 25px; text-align: center; margin: 30px 0;">
                        <p style="color: #666; margin: 0 0 10px 0; font-size: 14px; font-weight: 600;">AI Research Rating (Educational Only)</p>
                        <div style="font-size: 24px; font-weight: bold; color: {risk_style['color']};">
                            {risk_style['emoji']} {risk_rating} Risk
                        </div>
                        <p style="color: #666; margin: 10px 0 0 0; font-size: 12px;">*Experimental AI analysis - may be inaccurate</p>
                    </div>
                    
                    <!-- Summary -->
                    <div style="background: linear-gradient(135deg, #FFE8E0 0%, #FFF5F2 100%); border-radius: 15px; padding: 25px; margin: 30px 0;">
                        <h3 style="color: #FF8A50; margin: 0 0 15px 0; font-size: 18px;">📋 AI Research Summary (May Contain Inaccuracies)</h3>
                        <p style="color: #666; line-height: 1.6; margin: 0; font-size: 15px;">{summary}</p>
                        <p style="color: #999; margin: 15px 0 0 0; font-size: 12px; font-style: italic;">*This summary is AI-generated and for educational purposes only</p>
                    </div>
                    
                    <h3 style="color: #FF8A50; margin: 30px 0 15px 0; font-size: 20px;">🔍 What's Included in Your Research Preview:</h3>
                    <ul style="color: #666; line-height: 1.8; margin: 0; padding-left: 20px;">
                        <li><strong>AI Research Analysis</strong> - Educational insights (may be inaccurate)</li>
                        <li><strong>Research-Based Ideas</strong> - Educational content only, verify with experts</li>
                        <li><strong>Local Contractors</strong> - For professional consultation and verification</li>
                        <li><strong>Material Information</strong> - Research data only, verify with suppliers</li>
                        <li><strong>General Guidance</strong> - Educational info, check local requirements with officials</li>
                    </ul>
                    
                    <div style="text-align: center; margin: 40px 0;">
                        <a href="{assessment_url}" style="background: linear-gradient(135deg, #FF8A50 0%, #E67347 100%); color: white; padding: 18px 36px; text-decoration: none; border-radius: 12px; font-weight: bold; display: inline-block; font-size: 16px;">
                            📖 View Research Preview
                        </a>
                    </div>
                    
                    <div style="background-color: #F8F9FA; border-left: 4px solid #FF8A50; padding: 20px; margin: 30px 0; border-radius: 0 10px 10px 0;">
                        <p style="margin: 0; color: #666; font-size: 14px;">
                            <strong style="color: #FF8A50;">💡 Research Preview Reminder:</strong> This AI analysis is for educational purposes and may contain inaccuracies. Always consult qualified local fire safety professionals, contractors, and agencies before making any decisions.
                        </p>
                    </div>
                </div>
                
                <!-- Footer -->
                <div style="background-color: #2D3748; padding: 30px; text-align: center;">
                    <p style="color: #A0AEC0; margin: 0; font-size: 14px;">
                        © 2025 FlameGuardAI™ Research Preview. Educational AI tool - no professional claims made.
                    </p>
                    <p style="color: #A0AEC0; margin: 10px 0 0 0; font-size: 12px;">
                        Questions? Remember: this is a research preview. Consult local fire experts for professional advice.
                    </p>
                </div>
            </div>
        </body>
        </html>
        """

        text_content = f"""
        Research Analysis Complete - {name}!
        
        Your AI research preview analysis is complete! Our experimental AI tool has generated educational insights about your property.
        
        ⚠️ CRITICAL RESEARCH PREVIEW NOTICE: This AI analysis is experimental and may be inaccurate. Do not make fire safety decisions based solely on this research preview. Always consult qualified local fire departments, contractors, and inspectors.
        
        AI Research Rating (Educational Only): {risk_rating} Risk
        *Experimental AI analysis - may be inaccurate
        
        AI Research Summary (May Contain Inaccuracies):
        {summary}
        *This summary is AI-generated and for educational purposes only
        
        What's Included in Your Research Preview:
        • AI Research Analysis - Educational insights (may be inaccurate)
        • Research-Based Ideas - Educational content only, verify with experts
        • Local Contractors - For professional consultation and verification
        • Material Information - Research data only, verify with suppliers
        • General Guidance - Educational info, check local requirements with officials
        
        View your research preview: {assessment_url}
        
        Research Preview Reminder: This AI analysis is for educational purposes and may contain inaccuracies. Always consult qualified local fire safety professionals, contractors, and agencies before making any decisions.
        
        ---
        FlameGuardAI™ Research Preview Team
        Educational AI tool - no professional claims made
        
        Questions? Remember: this is a research preview. Consult local fire experts for professional advice.
        """

        text_part = MIMEText(text_content, 'plain')
        html_part = MIMEText(html_content, 'html')
        
        msg.attach(text_part)
        msg.attach(html_part)

        with smtplib.SMTP(SMTP_CONFIG['host'], SMTP_CONFIG['port']) as server:
            server.starttls()
            server.login(SMTP_CONFIG['user'], SMTP_CONFIG['password'])
            server.send_message(msg)
        
        logger.info(f"Assessment complete email sent to {email} for assessment {assessment_id}")
        return True
        
    except Exception as e:
        logger.error(f"Error sending assessment complete email to {email}: {e}")
        return False


def send_capacity_reached_email(recipient_email: str, max_users: int) -> bool:
    """
    Politely lets a prospective user know the service is at capacity and
    adds them to the priority list.  Returns True on success.
    """
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = "Thanks for your interest – we’re temporarily full"
        msg['From']    = SMTP_CONFIG['user']
        msg['To']      = recipient_email

        # ─── HTML body ───
        html_body = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
        <body style="margin:0;padding:0;font-family:Arial,sans-serif;background:#FFF5F2;">
          <div style="max-width:600px;margin:0 auto;background:#ffffff;border-radius:20px;
                      box-shadow:0 4px 20px rgba(0,0,0,0.1);overflow:hidden;">
            <!-- header -->
            <div style="background:linear-gradient(135deg,#FF8A50 0%,#E67347 100%);
                        padding:40px 30px;text-align:center;">
              <div style="background:#fff;width:60px;height:60px;border-radius:15px;
                          display:inline-flex;align-items:center;justify-content:center;margin-bottom:20px;">
                <span style="font-size:28px;">⏳</span>
              </div>
              <h1 style="color:#fff;margin:0;font-size:26px;font-weight:bold;">
                  Hang tight – we’ll open up soon!</h1>
              <p style="color:rgba(255,255,255,0.9);margin:10px 0 0;font-size:16px;">
                  FlameGuardAI™ is onboarding users in batches.</p>
            </div>

            <!-- content -->
            <div style="padding:40px 30px;">
              <p style="color:#333;font-size:16px;line-height:1.6;margin:0 0 20px 0;">
                 We’ve reached our current cohort limit of <strong>{max_users}</strong> active users.
                 Your email is now on the priority list, and we’ll notify you the
                 moment a slot opens up.</p>

              <p style="color:#333;font-size:16px;line-height:1.6;margin:0 0 20px 0;">
                 In the meantime you can explore our latest research notes and fire-safety
                 resources here:</p>

              <div style="text-align:center;margin:30px 0;">
                <a href="https://flameguardai.dlyog.com/"
                   style="background:linear-gradient(135deg,#FF8A50 0%,#E67347 100%);
                          color:#fff;padding:14px 28px;border-radius:10px;font-weight:bold;
                          text-decoration:none;display:inline-block;">View Resources 🔥</a>
              </div>

              <p style="color:#666;font-size:14px;line-height:1.6;margin:0;">
                 Thanks for your patience and interest!</p>
            </div>

            <!-- footer -->
            <div style="background:#2D3748;padding:25px;text-align:center;">
              <p style="color:#A0AEC0;font-size:12px;margin:0;">
                 © 2025 FlameGuardAI™ &nbsp;|&nbsp; Research Preview</p>
            </div>
          </div>
        </body>
        </html>
        """

        # ─── plain-text fallback ───
        text_body = f"""
FlameGuardAI™ – capacity reached

We’re flattered by the demand! The current cohort of {max_users} active users is full.
Your address has been placed on the priority list.  We’ll email you as soon as a slot
opens up.

In the meantime, browse our free fire-safety resources:
https://fireguardpro.com/resources

Thanks for your patience!
— The FlameGuardAI™ team
"""

        msg.attach(MIMEText(text_body, 'plain'))
        msg.attach(MIMEText(html_body , 'html'))

        with smtplib.SMTP(SMTP_CONFIG['host'], SMTP_CONFIG['port']) as server:
            server.starttls()
            server.login(SMTP_CONFIG['user'], SMTP_CONFIG['password'])
            server.send_message(msg)

        logger.info(f"Capacity-reached email sent to {recipient_email}")
        return True

    except Exception as e:
        logger.error(f"Error sending capacity-reached email to {recipient_email}: {e}")
        return False
