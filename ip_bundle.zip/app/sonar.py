"""
sonar.py
Utility for calling Perplexity‑AI Sonar and returning a clean dict
with keys `summary` and `detail_response`.
"""

import os
import json
import ast
import requests
from .prompt_utils import get_prompt_by_key 

# ----------------------------------------------------------------------
def _coerce_to_dict(text: str):
    """
    Robustly convert Sonar's response string to a Python dict.

    1. Try strict JSON
    2. Try Python literal (handles single quotes)
    3. Patch single quotes & newlines, then JSON again
    """
    # ① strict JSON
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # ② python‑style dict / mixed quotes
    try:
        return ast.literal_eval(text)
    except Exception:
        pass

    # ③ fallback: quick patch
    try:
        patched = (
            text.replace("'", '"')      # single → double quotes
                .replace('\n', '\\n')   # escape bare newlines inside strings
        )
        return json.loads(patched)
    except Exception:
        return None


# ----------------------------------------------------------------------
def get_sonar_response(prompt: str) -> dict:
    """
    Return Sonar response **always** as
        { "summary": str, "detail_response": str }
    """
    api_key = os.getenv("PERPLEXITY_API_KEY")
    url = "https://api.perplexity.ai/chat/completions"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    sonar_system_prompt = get_prompt_by_key("sonar_system")

    data = {
        "model": "sonar-pro",
        "messages": [
            {
                "role": "system",
                "content": sonar_system_prompt,
            },
            {"role": "user", "content": prompt},
        ],
    }

    # ---- API call ---------------------------------------------------
    r = requests.post(url, headers=headers, json=data)

    if r.status_code != 200:
        return {
            "summary": "Analysis service is temporarily unavailable. Please try again later.",
            "detail_response": "We're unable to complete your fire risk analysis at this moment due to a temporary service interruption. Your property assessment has been saved, and you can try generating the final report again in a few minutes. If you continue to experience issues, please contact our support team.",
        }

    content = r.json()["choices"][0]["message"]["content"].strip()

    # Remove ``` wrappers if present (improved handling)
    if content.startswith("```"):
        # Split by ``` and get the middle part
        parts = content.split("```")
        if len(parts) >= 3:
            content = parts[1].strip()
            # Remove language identifier if present (like "json")
            if content.lower().startswith("json"):
                content = content[4:].strip()
        else:
            # Fallback for malformed markdown
            content = content.replace("```", "").strip()

    parsed = _coerce_to_dict(content)

    if parsed and {"summary", "detail_response"} <= parsed.keys():
        return parsed

    # User-friendly fallback for parsing errors
    return {
        "summary": "We're experiencing technical difficulties with the analysis service. Please try again in a few moments.",
        "detail_response": "Our fire risk analysis system is temporarily unavailable. This may be due to high demand or a service interruption. Please try submitting your assessment again in a few minutes. If the problem persists, contact our support team for assistance. Your property images and information have been saved and can be re-analyzed once the service is restored.",
    }

def get_deep_research_analysis(vision_detail: str, zip_code: str, state: str, context: str = "") -> dict:
    """
    Conduct comprehensive deep research analysis using multiple Sonar API calls.
    Returns final comprehensive report with all research findings.
    """
    
    # Step 1: Risk Planning
    risk_planning_prompt = get_prompt_by_key("sonar_risk_planning").format(
        vision_detail=vision_detail,
        context=context,
        zip_code=zip_code,
        state=state
    )
    risk_planning_result = get_sonar_response(risk_planning_prompt)

    #print(risk_planning_result)
    
    # Extract focus areas from risk planning for next steps
    focus_areas = "roof safety, vegetation management, structural improvements, electrical systems, water access"
    
    # Step 2: DIY Solutions Research
    diy_prompt = get_prompt_by_key("sonar_diy_solutions").format(
        focus_areas=focus_areas,
        zip_code=zip_code,
        state=state
    )
    diy_result = get_sonar_response(diy_prompt)
    
    # Step 3: Contractor Research
    services_needed = "roof repairs, vegetation removal, deck construction, electrical work, water system installation"
    contractor_prompt = get_prompt_by_key("sonar_contractor_research").format(
        services_needed=services_needed,
        zip_code=zip_code,
        state=state
    )
    contractor_result = get_sonar_response(contractor_prompt)
    
    # Step 4: Supply Research
    materials_needed = "fire-resistant roofing, defensible space materials, irrigation supplies, electrical components"
    supply_prompt = get_prompt_by_key("sonar_supply_research").format(
        materials_needed=materials_needed,
        zip_code=zip_code,
        state=state
    )
    supply_result = get_sonar_response(supply_prompt)
    
    # Step 5: Generate Comprehensive Report
    final_prompt = get_prompt_by_key("sonar_comprehensive_report").format(
        vision_detail=vision_detail,
        risk_planning=risk_planning_result.get("detail_response", ""),
        diy_solutions=diy_result.get("detail_response", ""),
        contractor_info=contractor_result.get("detail_response", ""),
        supply_info=supply_result.get("detail_response", ""),
        zip_code=zip_code,
        state=state,
        context=context
    )
    
    final_result = get_sonar_response(final_prompt)
    
    # Return comprehensive result with all research data
    return {
        "summary": final_result.get("summary", "Comprehensive fire risk analysis completed"),
        "detail_response": final_result.get("detail_response", ""),
        "research_data": {
            "risk_planning": risk_planning_result,
            "diy_solutions": diy_result,
            "contractor_info": contractor_result,
            "supply_info": supply_result
        }
    }

def get_sonar_response_with_progress(prompt: str, step_name: str = "Analysis") -> dict:
    """
    Enhanced version of get_sonar_response that can be used with progress tracking.
    """
    print(f"Starting {step_name}...")  # You can replace this with your progress tracking system
    result = get_sonar_response(prompt)
    print(f"Completed {step_name}")
    return result