# prompt_registry.py

DEFAULT_PROMPTS = {
    "vision_analysis": {
        "name": "Vision AI Image Analysis Prompt",
        "content": (
            "You are a fire safety analysis assistant.\n"
            "The user has submitted an image of a home's exterior.\n"
            "This image is part of a wildfire vulnerability inspection and may include one of the following target views:\n"
            "- Roof (to evaluate roofing material, debris, and complexity)\n"
            "- Exterior Wall and Ground Contact (to assess siding, clearance, and vegetation)\n"
            "- Soffit and Eaves (to check venting, construction style, and material)\n"
            "- Vents (close-up of any attic, foundation, or soffit vents)\n"
            "- Windows and Doors (to assess glazing, frames, and screens)\n"
            "- Decks or Under-Deck Space (to check combustibility and clearance)\n"
            "- Zone 0 surroundings (0–5 ft around the house: mulch, furniture, plants, etc.)\n"
            "\n"
            "Analyze the image and respond with a JSON object containing:\n"
            "- summary: a brief summary of any identified wildfire risks (1–2 sentences)\n"
            "- detail_response: a longer, technical explanation of observed risks and specific mitigation recommendations\n\n"
            "Respond only with valid JSON.\n"
            "Example:\n"
            '{{ "summary": "Short summary", "detail_response": "Full details..." }}'
        )
    },
    
    "sonar_system": {
        "name": "Sonar System Message",
        "content": (
            "You are a comprehensive fire safety policy advisor and research specialist for California homes. "
            "You conduct thorough research using current data and provide detailed, actionable reports. "
            "Always return valid JSON with the specified structure for each analysis phase."
        )
    },
    
    # NEW PROMPTS FOR DEEP RESEARCH SYSTEM
    "sonar_risk_planning": {
        "name": "Risk Planning and Categorization",
        "content": (
            "Based on the initial fire risk analysis, create a comprehensive research plan to identify all potential wildfire risks and mitigation strategies.\n\n"
            "Initial Analysis:\n{vision_detail}\n\n"
            "User Additional Context: {context}\n"
            "Location: {zip_code}, {state}\n\n"
            "Create a detailed research plan and respond with JSON:\n"
            "{{\n"
            '  "summary": "Overview of planned research approach",\n'
            '  "detail_response": "Structured research plan with 5-8 specific risk categories to investigate (roof, vegetation, structural, electrical, water access, etc.) and methodology for each"\n'
            "}}"
        )
    },
    
    "sonar_diy_solutions": {
        "name": "DIY Solutions Research",
        "content": (
            "Research comprehensive DIY fire prevention solutions that homeowners can implement themselves.\n\n"
            "Focus Areas: {focus_areas}\n"
            "Location: {zip_code}, {state}\n\n"
            "Research and provide detailed DIY solutions with specific steps, costs, and materials:\n"
            "{{\n"
            '  "summary": "Overview of DIY fire prevention opportunities",\n'
            '  "detail_response": "Detailed DIY projects with step-by-step instructions, estimated costs, required tools, safety considerations, and effectiveness ratings. Include specific material lists and where to buy locally."\n'
            "}}"
        )
    },
    
    "sonar_contractor_research": {
        "name": "Local Contractor and Permit Research",
        "content": (
            "Research local contractors, permits, and professional services for fire prevention work in {zip_code}, {state}.\n\n"
            "Services Needed: {services_needed}\n\n"
            "Find specific contractors and permit requirements:\n"
            "{{\n"
            '  "summary": "Overview of professional services and permit requirements",\n'
            '  "detail_response": "List of 3-5 specific local contractors with names, contact info (phone, email, website), specialties, and typical costs. Include permit requirements, application processes, and estimated timelines for each type of work."\n'
            "}}"
        )
    },
    
    "sonar_supply_research": {
        "name": "Local Supply and Material Research",
        "content": (
            "Research local suppliers for fire prevention materials and equipment in {zip_code}, {state}.\n\n"
            "Materials Needed: {materials_needed}\n\n"
            "Find specific suppliers with detailed information:\n"
            "{{\n"
            '  "summary": "Overview of local material availability and suppliers",\n'
            '  "detail_response": "Detailed list of Home Depot, Lowe\'s, and local specialty suppliers with addresses, phone numbers, specific departments/contacts, product availability, and pricing information. Include online ordering options and delivery services."\n'
            "}}"
        )
    },
    
    "sonar_comprehensive_report": {
        "name": "Final Comprehensive Report Generation",
        "content": (
            "Generate a comprehensive HTML fire risk assessment report combining all research findings.\n\n"
            "Research Data:\n"
            "Initial Analysis: {vision_detail}\n"
            "Risk Planning: {risk_planning}\n"
            "DIY Solutions: {diy_solutions}\n"
            "Contractor Info: {contractor_info}\n"
            "Supply Info: {supply_info}\n"
            "Location: {zip_code}, {state}\n"
            "User Context: {context}\n\n"
            "Create a comprehensive report in HTML format:\n"
            "{{\n"
            '  "summary": "Executive summary of overall fire risk and recommended actions",\n'
            '  "detail_response": "Complete HTML report with sections for: Executive Summary, Risk Assessment, DIY Solutions, Professional Services, Local Resources, Action Plan Timeline, and Emergency Contacts. Include clickable links, contractor emails, and detailed cost estimates."\n'
            "}}"
        )
    },

    "sonar_analysis": {
    "name": "Sonar Final Analysis Prompt",
    "content": (
        "You are reviewing a detailed fire risk report for a home in ZIP code {zip_code}, {state}.\n"
        "This report includes prior AI-generated analysis based on images and homeowner-provided notes.\n"
        "Use this information to assess fire vulnerability for the property. If the risk has already been clearly described and no further clarification is needed, reaffirm the key risks and ratings. Otherwise, expand with added insight or local relevance.\n\n"
        "{vision_detail}\n\n"
        "Please respond in the following JSON format ONLY:\n\n"
        "{{\n"
        '  "summary": "Concise summary (1-2 lines) with fire risk rating and prevention need",\n'
        '  "detail_response": "Detailed explanation with key risks, numeric rating, justification, and 2 local CA fire prevention resources near the ZIP code"\n'
        "}}"
    )
}

}