import os
import base64
import json
import re
from openai import OpenAI
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
from .prompt_utils import get_prompt_by_key
# Initialize OpenAI client
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def analyze_image(image_path):

    vision_prompt = get_prompt_by_key("vision_analysis")

    # Read and encode the image to base64
    with open(image_path, "rb") as img_file:
        b64_image = base64.b64encode(img_file.read()).decode("utf-8")

    image_data_url = f"data:image/jpeg;base64,{b64_image}"

    #print(vision_prompt)

    # Request structured JSON from OpenAI
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": vision_prompt
                    },
                    {
                        "type": "image_url",
                        "image_url": {"url": image_data_url}
                    }
                ]
            }
        ],
        max_tokens=800
    )

    try:
        content = response.choices[0].message.content.strip()

        # Handle markdown formatting
        if content.startswith("```json"):
            content = content.split("```json", 1)[1].rsplit("```", 1)[0].strip()
        elif content.startswith("```"):
            content = content.split("```", 1)[1].rsplit("```", 1)[0].strip()

        return json.loads(content)

    except Exception as e:
        return {
            "summary": "Image analysis failed.",
            "detail_response": f"Error parsing response: {str(e)}. Raw content: {content}"
        }

